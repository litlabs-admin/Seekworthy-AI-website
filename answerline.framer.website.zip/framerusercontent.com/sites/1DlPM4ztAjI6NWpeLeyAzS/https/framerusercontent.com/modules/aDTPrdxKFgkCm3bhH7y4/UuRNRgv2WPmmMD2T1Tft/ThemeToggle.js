import {
    jsx as _jsx,
    jsxs as _jsxs
} from "react/jsx-runtime";
import {
    useEffect,
    useState
} from "react";
import {
    addPropertyControls
} from "framer"; // Light / dark toggle for Answerline.
// Follows the visitor's system setting until they click, then remembers the
// choice in localStorage ("answerline-theme"). It flips every color style at
// once by copying Framer's own light and dark token values into one forced
// rule. The site head runs the same code before first paint.
const KEY = "answerline-theme";
const ATTR = "data-answerline-theme";

function buildThemeCSS() {
    if (typeof document === "undefined") return;
    if (document.getElementById("answerline-theme-css")) return;
    const light = {};
    const dark = {};
    const read = (rules, target) => {
        for (const rule of Array.from(rules)) {
            if (rule instanceof CSSMediaRule) {
                const c = rule.conditionText || rule.media.mediaText;
                if (/prefers-color-scheme:\s*dark/.test(c)) read(rule.cssRules, dark);
                else if (/prefers-color-scheme:\s*light/.test(c)) read(rule.cssRules, light);
                continue;
            }
            if (rule instanceof CSSStyleRule) {
                const map = target || light;
                const s = rule.style;
                for (let i = 0; i < s.length; i++) {
                    const p = s[i];
                    if (p.startsWith("--token-")) map[p] = s.getPropertyValue(p).trim();
                }
            }
        }
    };
    for (const sheet of Array.from(document.styleSheets)) {
        try {
            read(sheet.cssRules, null);
        } catch (e) {}
    }
    const block = m => Object.entries(m).map(([k, v]) => `${k}:${v} !important;`).join("");
    const css = `html[${ATTR}="light"],html[${ATTR}="light"] body{color-scheme:light;${block(light)}}` + `html[${ATTR}="dark"],html[${ATTR}="dark"] body{color-scheme:dark;${block({...light,...dark})}}`;
    const el = document.createElement("style");
    el.id = "answerline-theme-css";
    el.textContent = css;
    document.head.appendChild(el);
}

function systemTheme() {
    if (typeof window === "undefined" || !window.matchMedia) return "dark";
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function currentTheme() {
    if (typeof document === "undefined") return "dark";
    const a = document.documentElement.getAttribute(ATTR);
    return a === "light" || a === "dark" ? a : systemTheme();
}

function setTheme(t, save = true) {
    buildThemeCSS();
    document.documentElement.setAttribute(ATTR, t);
    if (save) {
        try {
            localStorage.setItem(KEY, t);
        } catch (e) {}
    }
    window.dispatchEvent(new CustomEvent("answerline-theme", {
        detail: t
    }));
}
const tok = (id, fb) => `var(--token-${id}, ${fb})`;
const C = {
    line: tok("6ff1d9b2-b3bf-4a23-9432-bc3668be43a0", "#24272C"),
    surface: tok("e58286b7-f73d-4136-ad52-7268fdea9d4d", "#0E1013"),
    body: tok("aef431cf-2fb5-44f5-8001-55aa6f057d11", "#D9DCE1"),
    ink: tok("fc6ea28d-9846-439e-9315-fca4764d8f0d", "#EDEFF2"),
    accent: tok("1a7eaff3-439a-4045-9862-61ed45f5a886", "#8EA0FF")
};
const Sun = ({
    c
}) => /*#__PURE__*/ _jsxs("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 16 16",
    "aria-hidden": "true",
    children: [ /*#__PURE__*/ _jsx("circle", {
        cx: "8",
        cy: "8",
        r: "3",
        fill: "none",
        stroke: c,
        strokeWidth: "1.5"
    }), /*#__PURE__*/ _jsx("path", {
        d: "M8 1.5v1.5M8 13v1.5M1.5 8H3M13 8h1.5M3.4 3.4l1.06 1.06M11.54 11.54l1.06 1.06M3.4 12.6l1.06-1.06M11.54 4.46l1.06-1.06",
        fill: "none",
        stroke: c,
        strokeWidth: "1.5",
        strokeLinecap: "round"
    })]
});
const Moon = ({
    c
}) => /*#__PURE__*/ _jsx("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 16 16",
    "aria-hidden": "true",
    children: /*#__PURE__*/ _jsx("path", {
        d: "M13.5 9.6A5.5 5.5 0 0 1 6.4 2.5a5.5 5.5 0 1 0 7.1 7.1Z",
        fill: c,
        stroke: c,
        strokeWidth: "1",
        strokeLinejoin: "round"
    })
});
/**
 * @framerSupportedLayoutWidth fixed
 * @framerSupportedLayoutHeight fixed
 * @framerIntrinsicWidth 34
 * @framerIntrinsicHeight 34
 */
export default function ThemeToggle(props) {
    const [theme, set] = useState("dark");
    const [hover, setHover] = useState(false);
    const [focus, setFocus] = useState(false);
    useEffect(() => {
        let saved = null;
        try {
            saved = localStorage.getItem(KEY);
        } catch (e) {}
        if (saved === "light" || saved === "dark") setTheme(saved, false);
        set(currentTheme());
        const onTheme = e => set(e.detail);
        const mq = window.matchMedia ? .("(prefers-color-scheme: dark)");
        const onSystem = () => {
            if (!document.documentElement.getAttribute(ATTR)) set(systemTheme());
        };
        window.addEventListener("answerline-theme", onTheme);
        mq ? .addEventListener ? .("change", onSystem);
        return () => {
            window.removeEventListener("answerline-theme", onTheme);
            mq ? .removeEventListener ? .("change", onSystem);
        };
    }, []);
    const next = theme === "dark" ? "light" : "dark";
    const toggle = () => {
        setTheme(next);
        set(next);
    };
    return /*#__PURE__*/ _jsx("button", {
        type: "button",
        "aria-label": `Switch to ${next} mode`,
        title: `Switch to ${next} mode`,
        onClick: toggle,
        onMouseEnter: () => setHover(true),
        onMouseLeave: () => setHover(false),
        onFocus: () => setFocus(true),
        onBlur: () => setFocus(false),
        style: {
            all: "unset",
            boxSizing: "border-box",
            width: "100%",
            height: "100%",
            minWidth: 34,
            minHeight: 34,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            borderRadius: 8,
            cursor: "pointer",
            background: hover ? C.surface : "transparent",
            boxShadow: `inset 0 0 0 1px ${C.line}`,
            outline: focus ? `2px solid ${C.accent}` : "none",
            outlineOffset: 2,
            transition: "background 0.2s ease",
            ...props.style
        },
        children: theme === "dark" ? /*#__PURE__*/ _jsx(Moon, {
            c: hover ? C.ink : C.body
        }) : /*#__PURE__*/ _jsx(Sun, {
            c: hover ? C.ink : C.body
        })
    });
}
ThemeToggle.displayName = "Theme toggle";
addPropertyControls(ThemeToggle, {});
export const __FramerMetadata__ = {
    "exports": {
        "default": {
            "type": "reactComponent",
            "name": "ThemeToggle",
            "slots": [],
            "annotations": {
                "framerSupportedLayoutHeight": "fixed",
                "framerIntrinsicHeight": "34",
                "framerSupportedLayoutWidth": "fixed",
                "framerContractVersion": "1",
                "framerIntrinsicWidth": "34"
            }
        },
        "__FramerMetadata__": {
            "type": "variable"
        }
    }
}
//# sourceMappingURL=./ThemeToggle.map