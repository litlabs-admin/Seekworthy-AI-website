// src/code-generation/components/cms/bundled/getRichTextJsonResolver.tsx?bundle
import {
    jsx as e
} from "react/jsx-runtime";
import {
    AutoBreakpointVariant as r,
    ComponentPresetsConsumer as t,
    Link as n,
    motion as o
} from "framer"; // ../../library/src/router/lazy.tsx
import {
    isValidElement as i
} from "react"; // ../../library/src/utils/utils.ts
var a, f, u = "undefined" != typeof window,
    c = u && "function" == typeof window.requestIdleCallback,
    l = "preload";

function p(e) {
    return "object" == typeof e && null !== e && ! /*#__PURE__*/ i(e) && l in e;
} // src/code-generation/components/cms/bundled/getRichTextJsonResolver.tsx?bundle
import {
    Fragment as s,
    createElement as m
} from "react"; // src/code-generation/components/cms/bundled/assert.ts
function d(e, ...r) {
    if (!e) throw Error("Assertion Error" + (r.length > 0 ? ": " + r.join(" ") : ""));
} // src/code-generation/components/cms/bundled/getRichTextJsonResolver.tsx?bundle
var y = ((a = y || {})[a.Fragment = 1] = "Fragment", a[a.Link = 2] = "Link", a[a.Module = 3] = "Module", a[a.Tag = 4] = "Tag", a[a.Text = 5] = "Text", a),
    h = ((f = h || {})[f.RichText = 1] = "RichText", f[f.VectorSetItem = 2] = "VectorSetItem", f);

function x(e, r, t) {
    for (let [n, o] of Object.entries(r)) {
        let r = e[n];
        if ("number" == typeof o) {
            e[n] = t(o, r);
            continue;
        }
        T(r, o, t);
    }
}

function T(e, r, t) {
    if ("number" != typeof r) {
        if (Array.isArray(r)) {
            if (!Array.isArray(e)) return;
            let [n] = r;
            for (let r = 0; r < e.length; r++) {
                let o = e[r];
                "number" == typeof n ? e[r] = t(n, o) : T(o, n, t);
            }
            return;
        }
        null === e || "object" != typeof e || Array.isArray(e) || x(e, r, t);
    }
}

function g(i) {
    let a = /* @__PURE__ */ new Map;
    return f => {
        let u = a.get(f);
        if (u) return u;
        let c = JSON.parse(f),
            l = function a(f) {
                switch (f[0]) {
                    case 1 /* Fragment */ :
                        {
                            let [, ...e] = f,
                            r = e.map(a);
                            return /*#__PURE__*/ m(s, void 0, ...r);
                        }
                    case 2 /* Link */ :
                        {
                            let [, e, ...r] = f,
                            t = r.map(a);
                            return /*#__PURE__*/ m(n, e, ...t);
                        }
                    case 3 /* Module */ :
                        {
                            let [, n, o, u] = f;x(o, u, (e, r) => {
                                if (1 /* RichText */ === e) return r ? a(r) : r;
                                if ("string" != typeof r) return r;
                                let t = i[r];
                                return t ? (p(t) && t.preload(), t) : r;
                            });
                            let c = i[n];
                            return d(c, "Module not found"),
                            p(c) && c.preload(),
                            /*#__PURE__*/ e(t, {
                                componentIdentifier: n,
                                children: t => /*#__PURE__*/ e(r, {
                                    component: c,
                                    props: { ...t,
                                        ...o
                                    }
                                })
                            });
                        }
                    case 4 /* Tag */ :
                        {
                            let [, e, r, ...t] = f,
                            n = t.map(a);
                            if ("a" === e) return /*#__PURE__*/ m(o.a, r, ...n);
                            return /*#__PURE__*/ m(e, r, ...n);
                        }
                    case 5 /* Text */ :
                        {
                            let [, e] = f;
                            return e;
                        }
                }
            }(c);
        return a.set(f, l), l;
    };
}
export {
    h as RichTextJsonPropKind, y as RichTextJsonType, g as getRichTextJsonResolver, x as mapRichTextJsonProps
};
export const __FramerMetadata__ = {
    "exports": {
        "RichTextJsonPropKind": {
            "type": "variable",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "mapRichTextJsonProps": {
            "type": "function",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "RichTextJsonType": {
            "type": "variable",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "getRichTextJsonResolver": {
            "type": "reactComponent",
            "name": "getRichTextJsonResolver",
            "slots": [],
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "__FramerMetadata__": {
            "type": "variable"
        }
    }
}