function t(t, e, r) {
    return e in t ? Object.defineProperty(t, e, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = r, t;
}
var e, r, i = Object.create,
    n = Object.defineProperty,
    s = Object.getOwnPropertyDescriptor,
    o = Object.getOwnPropertyNames,
    a = Object.getPrototypeOf,
    u = Object.prototype.hasOwnProperty,
    l = (t, e) => function() {
        try {
            return e || (0, t[o(t)[0]])((e = {
                exports: {}
            }).exports, e), e.exports;
        } catch (t) {
            throw e = 0, t;
        }
    },
    h = (t, e, r, i) => {
        if (e && "object" == typeof e || "function" == typeof e)
            for (let a of o(e)) u.call(t, a) || a === r || n(t, a, {
                get: () => e[a],
                enumerable: !(i = s(e, a)) || i.enumerable
            });
        return t;
    },
    c = (t, e, r) => (r = null != t ? i(a(t)) : {}, h( // If the importer is in node compatibility mode or this is not an ESM
        // file that has been converted to a CommonJS file using a Babel-
        // compatible transform (i.e. "__esModule" has not been set), then set
        // "default" to the CommonJS "module.exports" for node compatibility.
        !e && t && t.__esModule ? r : n(r, "default", {
            value: t,
            enumerable: !0
        }), t)),
    f = l({
        "../../../node_modules/dataloader/index.js" (t, e) {
            var r, i = /* @__PURE__ */ function() {
                    function t(t, e) {
                        if ("function" != typeof t) throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but got: " + t + ".");
                        this._batchLoadFn = t, this._maxBatchSize = function(t) {
                            if (!(!t || !1 !== t.batch)) return 1;
                            var e = t && t.maxBatchSize;
                            if (void 0 === e) return 1 / 0;
                            if ("number" != typeof e || e < 1) throw TypeError("maxBatchSize must be a positive number: " + e);
                            return e;
                        }(e), this._batchScheduleFn = function(t) {
                            var e = t && t.batchScheduleFn;
                            if (void 0 === e) return n;
                            if ("function" != typeof e) throw TypeError("batchScheduleFn must be a function: " + e);
                            return e;
                        }(e), this._cacheKeyFn = function(t) {
                            var e = t && t.cacheKeyFn;
                            if (void 0 === e) return function(t) {
                                return t;
                            };
                            if ("function" != typeof e) throw TypeError("cacheKeyFn must be a function: " + e);
                            return e;
                        }(e), this._cacheMap = function(t) {
                            if (!(!t || !1 !== t.cache)) return null;
                            var e = t && t.cacheMap;
                            if (void 0 === e) return /* @__PURE__ */ new Map;
                            if (null !== e) {
                                var r = ["get", "set", "delete", "clear"].filter(function(t) {
                                    return e && "function" != typeof e[t];
                                });
                                if (0 !== r.length) throw TypeError("Custom cacheMap missing methods: " + r.join(", "));
                            }
                            return e;
                        }(e), this._batch = null, this.name = e && e.name ? e.name : null;
                    }
                    var e = t.prototype;
                    return e.load = function(t) {
                        if (null == t) throw TypeError("The loader.load() function must be called with a value, but got: " + String(t) + ".");
                        var e = function(t) {
                                var e = t._batch;
                                if (null !== e && !e.hasDispatched && e.keys.length < t._maxBatchSize) return e;
                                var r = {
                                    hasDispatched: !1,
                                    keys: [],
                                    callbacks: []
                                };
                                return t._batch = r, t._batchScheduleFn(function() {
                                    (function(t, e) {
                                        var r;
                                        if (e.hasDispatched = !0, 0 === e.keys.length) {
                                            o(e);
                                            return;
                                        }
                                        try {
                                            r = t._batchLoadFn(e.keys);
                                        } catch (r) {
                                            return s(t, e, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function errored synchronously: " + String(r) + "."));
                                        }
                                        if (!r || "function" != typeof r.then) return s(t, e, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise: " + String(r) + "."));
                                        r.then(function(t) {
                                            if (!a(t)) throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array: " + String(t) + ".");
                                            if (t.length !== e.keys.length) throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array of the same length as the Array of keys.\n\nKeys:\n" + String(e.keys) + "\n\nValues:\n" + String(t));
                                            o(e);
                                            for (var r = 0; r < e.callbacks.length; r++) {
                                                var i = t[r];
                                                i instanceof Error ? e.callbacks[r].reject(i) : e.callbacks[r].resolve(i);
                                            }
                                        }).catch(function(r) {
                                            s(t, e, r);
                                        });
                                    })(t, r);
                                }), r;
                            }(this),
                            r = this._cacheMap,
                            i = this._cacheKeyFn(t);
                        if (r) {
                            var n = r.get(i);
                            if (n) {
                                var u = e.cacheHits || (e.cacheHits = []);
                                return new Promise(function(t) {
                                    u.push(function() {
                                        t(n);
                                    });
                                });
                            }
                        }
                        e.keys.push(t);
                        var l = new Promise(function(t, r) {
                            e.callbacks.push({
                                resolve: t,
                                reject: r
                            });
                        });
                        return r && r.set(i, l), l;
                    }, e.loadMany = function(t) {
                        if (!a(t)) throw TypeError("The loader.loadMany() function must be called with Array<key> but got: " + t + ".");
                        for (var e = [], r = 0; r < t.length; r++) e.push(this.load(t[r]).catch(function(t) {
                            return t;
                        }));
                        return Promise.all(e);
                    }, e.clear = function(t) {
                        var e = this._cacheMap;
                        if (e) {
                            var r = this._cacheKeyFn(t);
                            e.delete(r);
                        }
                        return this;
                    }, e.clearAll = function() {
                        var t = this._cacheMap;
                        return t && t.clear(), this;
                    }, e.prime = function(t, e) {
                        var r = this._cacheMap;
                        if (r) {
                            var i, n = this._cacheKeyFn(t);
                            void 0 === r.get(n) && (e instanceof Error ? (i = Promise.reject(e)).catch(function() {}) : i = Promise.resolve(e), r.set(n, i));
                        }
                        return this;
                    }, t;
                }(),
                n = "object" == typeof process && "function" == typeof process.nextTick ? function(t) {
                    r || (r = Promise.resolve()), r.then(function() {
                        process.nextTick(t);
                    });
                } : "function" == typeof setImmediate ? function(t) {
                    setImmediate(t);
                } : function(t) {
                    setTimeout(t);
                };

            function s(t, e, r) {
                o(e);
                for (var i = 0; i < e.keys.length; i++) t.clear(e.keys[i]), e.callbacks[i].reject(r);
            }

            function o(t) {
                if (t.cacheHits)
                    for (var e = 0; e < t.cacheHits.length; e++) t.cacheHits[e]();
            }

            function a(t) {
                return "object" == typeof t && null !== t && "number" == typeof t.length && (0 === t.length || t.length > 0 && Object.prototype.hasOwnProperty.call(t, t.length - 1));
            }
            e.exports = i;
        }
    }),
    d = c(f(), 1);
import {
    yieldToMain as g
} from "framer"; // ../../shared/src/yield.ts
function v(t) {
    return "function" == typeof t ? t() : t;
}
var y = {
    background: 0,
    "user-visible": 1,
    "user-blocking": 2
};

function p(t, e) {
    return y[t] > y[e];
} // ../../library/src/utils/schedulerPriority.ts
function m(t) {
    let e;
    for (let r of t) {
        let t = v(r);
        if ((void 0 === e || p(t, e)) && (e = t), "user-blocking" === e) break;
    }
    return e;
} // src/code-generation/components/cms/bundled/BufferReader.ts
var w = {
        Uint8: 1,
        Uint16: 2,
        Uint32: 4,
        BigUint64: 8,
        Int8: 1,
        Int16: 2,
        Int32: 4,
        BigInt64: 8,
        Float32: 4,
        Float64: 8
    },
    b = (e = class e {
            getOffset() {
                return this.offset;
            }
            ensureLength(t) {
                let e = this.bytes.length;
                if (!(this.offset + t <= e)) throw Error("Reading out of bounds");
            }
            readUint8() {
                let t = w.Uint8;
                this.ensureLength(t);
                let e = this.view.getUint8(this.offset);
                return this.offset += t, e;
            }
            readUint16() {
                let t = w.Uint16;
                this.ensureLength(t);
                let e = this.view.getUint16(this.offset);
                return this.offset += t, e;
            }
            readUint32() {
                let t = w.Uint32;
                this.ensureLength(t);
                let e = this.view.getUint32(this.offset);
                return this.offset += t, e;
            }
            readUint64() {
                let t = this.readBigUint64();
                return Number(t);
            }
            readBigUint64() {
                let t = w.BigUint64;
                this.ensureLength(t);
                let e = this.view.getBigUint64(this.offset);
                return this.offset += t, e;
            }
            readInt8() {
                let t = w.Int8;
                this.ensureLength(t);
                let e = this.view.getInt8(this.offset);
                return this.offset += t, e;
            }
            readInt16() {
                let t = w.Int16;
                this.ensureLength(t);
                let e = this.view.getInt16(this.offset);
                return this.offset += t, e;
            }
            readInt32() {
                let t = w.Int32;
                this.ensureLength(t);
                let e = this.view.getInt32(this.offset);
                return this.offset += t, e;
            }
            readInt64() {
                let t = this.readBigInt64();
                return Number(t);
            }
            readBigInt64() {
                let t = w.BigInt64;
                this.ensureLength(t);
                let e = this.view.getBigInt64(this.offset);
                return this.offset += t, e;
            }
            readFloat32() {
                let t = w.Float32;
                this.ensureLength(t);
                let e = this.view.getFloat32(this.offset);
                return this.offset += t, e;
            }
            readFloat64() {
                let t = w.Float64;
                this.ensureLength(t);
                let e = this.view.getFloat64(this.offset);
                return this.offset += t, e;
            }
            readBytes(t) {
                let e = this.offset,
                    r = e + t,
                    i = this.bytes.subarray(e, r);
                return this.offset = r, i;
            }
            readString() {
                let t = this.readUint32(),
                    r = this.readBytes(t);
                return e.textDecoder.decode(r);
            }
            readJson() {
                let t = this.readString();
                return JSON.parse(t);
            }
            constructor(e) {
                t(this, "bytes", void 0), t(this, "offset", 0), t(this, "view", void 0), this.bytes = e, this.view = I(this.bytes);
            }
        }, // TextDecoder has no per-decode state unless streaming is enabled. Reusing one class-owned decoder
        // avoids constructing one for every CMS item, where each item gets its own BufferReader.
        t(e, "textDecoder", new TextDecoder), e);

function I(t) {
    return new DataView(t.buffer, t.byteOffset, t.byteLength);
} // src/code-generation/components/cms/bundled/DatabaseDictionaryIndex.ts
import {
    ControlType as S,
    yieldToMain as U
} from "framer"; // ../../library/src/utils/utils.ts
var k = "undefined" != typeof window,
    L = k && "function" == typeof window.requestIdleCallback; // src/code-generation/components/cms/bundled/assert.ts
function B(t, ...e) {
    if (!t) throw Error("Assertion Error" + (e.length > 0 ? ": " + e.join(" ") : ""));
}

function E(t) {
    throw Error(`Unexpected value: ${t}`);
} // src/code-generation/components/cms/bundled/BufferWriter.ts
var M = 1024,
    P = 1.5,
    T = t => 2 ** t - 1,
    x = t => -(2 ** (t - 1)),
    F = t => 2 ** (t - 1) - 1,
    N = {
        Uint8: 0,
        Uint16: 0,
        Uint32: 0,
        Uint64: 0,
        BigUint64: 0,
        Int8: x(8),
        Int16: x(16),
        Int32: x(32),
        Int64: Number.MIN_SAFE_INTEGER,
        BigInt64: -(BigInt(2) ** BigInt(63))
    },
    A = {
        Uint8: T(8),
        Uint16: T(16),
        Uint32: T(32),
        Uint64: Number.MAX_SAFE_INTEGER,
        BigUint64: BigInt(2) ** BigInt(64) - BigInt(1),
        Int8: F(8),
        Int16: F(16),
        Int32: F(32),
        Int64: Number.MAX_SAFE_INTEGER,
        BigInt64: BigInt(2) ** BigInt(63) - BigInt(1)
    };

function q(t, e, r, i) {
    B(t >= e, t, "outside lower bound for", i), B(t <= r, t, "outside upper bound for", i);
}
var O = class {
    getOffset() {
        return this.offset;
    }
    slice(t = 0, e = this.offset) {
        return this.bytes.slice(t, e);
    }
    subarray(t = 0, e = this.offset) {
        return this.bytes.subarray(t, e);
    }
    ensureLength(t) {
        let e = this.bytes.length;
        if (this.offset + t <= e) return;
        let r = new Uint8Array(Math.ceil(e * P) + t);
        r.set(this.bytes), this.bytes = r, this.view = I(r);
    }
    writeUint8(t) {
        q(t, N.Uint8, A.Uint8, "Uint8");
        let e = w.Uint8;
        this.ensureLength(e), this.view.setUint8(this.offset, t), this.offset += e;
    }
    writeUint16(t) {
        q(t, N.Uint16, A.Uint16, "Uint16");
        let e = w.Uint16;
        this.ensureLength(e), this.view.setUint16(this.offset, t), this.offset += e;
    }
    writeUint32(t) {
        q(t, N.Uint32, A.Uint32, "Uint32");
        let e = w.Uint32;
        this.ensureLength(e), this.view.setUint32(this.offset, t), this.offset += e;
    }
    writeUint64(t) {
        q(t, N.Uint64, A.Uint64, "Uint64");
        let e = BigInt(t);
        this.writeBigUint64(e);
    }
    writeBigUint64(t) {
        q(t, N.BigUint64, A.BigUint64, "BigUint64");
        let e = w.BigUint64;
        this.ensureLength(e), this.view.setBigUint64(this.offset, t), this.offset += e;
    }
    writeInt8(t) {
        q(t, N.Int8, A.Int8, "Int8");
        let e = w.Int8;
        this.ensureLength(e), this.view.setInt8(this.offset, t), this.offset += e;
    }
    writeInt16(t) {
        q(t, N.Int16, A.Int16, "Int16");
        let e = w.Int16;
        this.ensureLength(e), this.view.setInt16(this.offset, t), this.offset += e;
    }
    writeInt32(t) {
        q(t, N.Int32, A.Int32, "Int32");
        let e = w.Int32;
        this.ensureLength(e), this.view.setInt32(this.offset, t), this.offset += e;
    }
    writeInt64(t) {
        q(t, N.Int64, A.Int64, "Int64");
        let e = BigInt(t);
        this.writeBigInt64(e);
    }
    writeBigInt64(t) {
        q(t, N.BigInt64, A.BigInt64, "BigInt64");
        let e = w.BigInt64;
        this.ensureLength(e), this.view.setBigInt64(this.offset, t), this.offset += e;
    }
    writeFloat32(t) {
        let e = w.Float32;
        this.ensureLength(e), this.view.setFloat32(this.offset, t), this.offset += e;
    }
    writeFloat64(t) {
        let e = w.Float64;
        this.ensureLength(e), this.view.setFloat64(this.offset, t), this.offset += e;
    }
    writeBytes(t) {
        let e = t.length;
        this.ensureLength(e), this.bytes.set(t, this.offset), this.offset += e;
    }
    encodeString(t) {
        let e = this.encodedStrings.get(t);
        if (e) return e;
        let r = this.encoder.encode(t);
        return this.encodedStrings.set(t, r), r;
    }
    writeString(t) {
        let e = this.encodeString(t),
            r = e.length;
        this.writeUint32(r), this.writeBytes(e);
    }
    writeJson(t) {
        let e = JSON.stringify(t);
        this.writeString(e);
    }
    constructor() {
        t(this, "offset", 0), t(this, "bytes", new Uint8Array(M)), t(this, "view", I(this.bytes)), t(this, "encoder", new TextEncoder), t(this, "encodedStrings", /* @__PURE__ */ new Map);
    }
}; // src/utils/typeChecks.ts
function _(t) {
    return "string" == typeof t;
}

function j(t) {
    return Number.isFinite(t);
}

function D(t) {
    return null === t;
} // src/code-generation/components/cms/bundled/models/DatabaseItemPointerModel.ts
var R = class e {
    static fromString(t) {
        let [r, i, n] = t.split("/").map(Number);
        return B(j(r), "Invalid chunkId"), B(j(i), "Invalid offset"), B(j(n), "Invalid length"), new e(r, i, n);
    }
    toString() {
        return `${this.chunkId}/${this.offset}/${this.length}`;
    }
    static read(t) {
        let r = t.readUint16(),
            i = t.readUint32(),
            n = t.readUint32();
        return new e(r, i, n);
    }
    write(t) {
        t.writeUint16(this.chunkId), t.writeUint32(this.offset), t.writeUint32(this.length);
    }
    compare(t) {
        return this.chunkId < t.chunkId ? -1 : this.chunkId > t.chunkId ? 1 : this.offset < t.offset ? -1 : this.offset > t.offset ? 1 : (B(this.length === t.length), 0);
    }
    constructor(e, r, i) {
        t(this, "chunkId", void 0), t(this, "offset", void 0), t(this, "length", void 0), this.chunkId = e, this.offset = r, this.length = i;
    }
}; // src/code-generation/components/cms/bundled/models/DatabaseValueModel.ts
function C(t) {
    if (D(t)) return 0 /* Null */ ;
    switch (t.type) {
        case "array" /* Array */ :
            return 1 /* Array */ ;
        case "boolean" /* Boolean */ :
            return 2 /* Boolean */ ;
        case "color" /* Color */ :
            return 3 /* Color */ ;
        case "date" /* Date */ :
            return 4 /* Date */ ;
        case "enum" /* Enum */ :
            return 5 /* Enum */ ;
        case "file" /* File */ :
            return 6 /* File */ ;
        case "responsiveimage" /* ResponsiveImage */ :
            return 10 /* ResponsiveImage */ ;
        case "link" /* Link */ :
            return 7 /* Link */ ;
        case "number" /* Number */ :
            return 8 /* Number */ ;
        case "object" /* Object */ :
            return 9 /* Object */ ;
        case "richtext" /* RichText */ :
            return 11 /* RichText */ ;
        case "string" /* String */ :
            return 12 /* String */ ;
        case "vectorsetitem" /* VectorSetItem */ :
            return 13 /* VectorSetItem */ ;
        default:
            E(t);
    }
}

function J(t) {
    let e = t.readUint16(),
        i = [];
    for (let n = 0; n < e; n++) {
        let e = r.read(t);
        i.push(e);
    }
    return {
        type: "array" /* Array */ ,
        value: i
    };
}

function W(t, e) {
    for (let i of (t.writeUint16(e.value.length), e.value)) r.write(t, i);
}

function $(t, e, i) {
    let n = t.value.length,
        s = e.value.length;
    if (n < s) return -1;
    if (n > s) return 1;
    for (let s = 0; s < n; s++) {
        let n = t.value[s],
            o = e.value[s],
            a = r.compare(n, o, i);
        if (0 !== a) return a;
    }
    return 0;
}

function z(t) {
    return {
        type: "boolean" /* Boolean */ ,
        value: 0 !== t.readUint8()
    };
}

function K(t, e) {
    t.writeUint8(e.value ? 1 : 0);
}

function G(t, e) {
    return t.value < e.value ? -1 : t.value > e.value ? 1 : 0;
}

function V(t) {
    return {
        type: "color" /* Color */ ,
        value: t.readString()
    };
}

function H(t, e) {
    t.writeString(e.value);
}

function X(t, e) {
    return t.value < e.value ? -1 : t.value > e.value ? 1 : 0;
}

function Q(t) {
    let e = t.readInt64(),
        r = new Date(e);
    return {
        type: "date" /* Date */ ,
        value: r.toISOString()
    };
}

function Y(t, e) {
    let r = new Date(e.value),
        i = r.getTime();
    t.writeInt64(i);
}

function Z(t, e) {
    let r = new Date(t.value),
        i = new Date(e.value);
    return r < i ? -1 : r > i ? 1 : 0;
}

function tt(t) {
    return {
        type: "enum" /* Enum */ ,
        value: t.readString()
    };
}

function te(t, e) {
    t.writeString(e.value);
}

function tr(t, e) {
    return t.value < e.value ? -1 : t.value > e.value ? 1 : 0;
}

function ti(t) {
    return {
        type: "file" /* File */ ,
        value: t.readString()
    };
}

function tn(t, e) {
    t.writeString(e.value);
}

function ts(t, e) {
    return t.value < e.value ? -1 : t.value > e.value ? 1 : 0;
}

function to(t) {
    return {
        type: "link" /* Link */ ,
        value: t.readJson()
    };
}

function ta(t, e) {
    t.writeJson(e.value);
}

function tu(t, e) {
    let r = JSON.stringify(t.value),
        i = JSON.stringify(e.value);
    return r < i ? -1 : r > i ? 1 : 0;
}

function tl(t) {
    return {
        type: "number" /* Number */ ,
        value: t.readFloat64()
    };
}

function th(t, e) {
    t.writeFloat64(e.value);
}

function tc(t, e) {
    return t.value < e.value ? -1 : t.value > e.value ? 1 : 0;
}

function tf(t) {
    let e = t.readUint16(),
        i = {};
    for (let n = 0; n < e; n++) {
        let e = t.readString();
        i[e] = r.read(t);
    }
    return {
        type: "object" /* Object */ ,
        value: i
    };
}

function td(t, e) {
    let i = Object.entries(e.value);
    for (let [e, n] of (t.writeUint16(i.length), i)) t.writeString(e), r.write(t, n);
}

function tg(t, e, i) {
    let n = Object.keys(t.value).sort(),
        s = Object.keys(e.value).sort();
    if (n.length < s.length) return -1;
    if (n.length > s.length) return 1;
    for (let o = 0; o < n.length; o++) {
        let a = n[o],
            u = s[o];
        if (a < u) return -1;
        if (a > u) return 1;
        let l = t.value[a] ? ? null,
            h = e.value[u] ? ? null,
            c = r.compare(l, h, i);
        if (0 !== c) return c;
    }
    return 0;
}

function tv(t) {
    return {
        type: "responsiveimage" /* ResponsiveImage */ ,
        value: t.readJson()
    };
}

function ty(t, e) {
    t.writeJson(e.value);
}

function tp(t, e) {
    let r = JSON.stringify(t.value),
        i = JSON.stringify(e.value);
    return r < i ? -1 : r > i ? 1 : 0;
}

function tm(t) {
    let e = t.readInt8();
    if (0 === e) return {
        type: "richtext" /* RichText */ ,
        value: t.readUint32()
    };
    if (1 === e) return {
        type: "richtext" /* RichText */ ,
        value: t.readString()
    };
    throw Error("Invalid rich text pointer");
}

function tw(t, e) {
    if (j(e.value)) {
        t.writeInt8(0), t.writeUint32(e.value);
        return;
    }
    if (_(e.value)) {
        t.writeInt8(1), t.writeString(e.value);
        return;
    }
    throw Error("Invalid rich text pointer");
}

function tb(t, e) {
    let r = t.value,
        i = e.value;
    if (j(r) && j(i) || _(r) && _(i)) return r < i ? -1 : r > i ? 1 : 0;
    throw Error("Invalid rich text pointer");
}

function tI(t) {
    return {
        type: "string" /* String */ ,
        value: t.readString()
    };
}

function tS(t, e) {
    t.writeString(e.value);
}

function tU(t, e, r) {
    let i = t.value,
        n = e.value;
    return (0 /* CaseInsensitive */ === r.type && (i = t.value.toLowerCase(), n = e.value.toLowerCase()), i < n) ? -1 : i > n ? 1 : 0;
}

function tk(t) {
    return {
        type: "vectorsetitem" /* VectorSetItem */ ,
        value: t.readUint32()
    };
}

function tL(t, e) {
    t.writeUint32(e.value);
}

function tB(t, e) {
    let r = t.value,
        i = e.value;
    return r < i ? -1 : r > i ? 1 : 0;
}(t => {
    t.read = function(t) {
        let e = t.readUint8();
        switch (e) {
            case 0 /* Null */ :
                return null;
            case 1 /* Array */ :
                return J(t);
            case 2 /* Boolean */ :
                return z(t);
            case 3 /* Color */ :
                return V(t);
            case 4 /* Date */ :
                return Q(t);
            case 5 /* Enum */ :
                return tt(t);
            case 6 /* File */ :
                return ti(t);
            case 7 /* Link */ :
                return to(t);
            case 8 /* Number */ :
                return tl(t);
            case 9 /* Object */ :
                return tf(t);
            case 10 /* ResponsiveImage */ :
                return tv(t);
            case 11 /* RichText */ :
                return tm(t);
            case 12 /* String */ :
                return tI(t);
            case 13 /* VectorSetItem */ :
                return tk(t);
            default:
                E(e);
        }
    }, t.write = function(t, e) {
        let r = C(e);
        if (t.writeUint8(r), !D(e)) switch (e.type) {
            case "array" /* Array */ :
                return W(t, e);
            case "boolean" /* Boolean */ :
                return K(t, e);
            case "color" /* Color */ :
                return H(t, e);
            case "date" /* Date */ :
                return Y(t, e);
            case "enum" /* Enum */ :
                return te(t, e);
            case "file" /* File */ :
                return tn(t, e);
            case "link" /* Link */ :
                return ta(t, e);
            case "number" /* Number */ :
                return th(t, e);
            case "object" /* Object */ :
                return td(t, e);
            case "responsiveimage" /* ResponsiveImage */ :
                return ty(t, e);
            case "richtext" /* RichText */ :
                return tw(t, e);
            case "vectorsetitem" /* VectorSetItem */ :
                return tL(t, e);
            case "string" /* String */ :
                return tS(t, e);
            default:
                E(e);
        }
    }, t.compare = function(t, e, r) {
        let i = C(t),
            n = C(e);
        if (i < n) return -1;
        if (i > n) return 1;
        if (D(t) || D(e)) return 0;
        switch (t.type) {
            case "array" /* Array */ :
                return B("array" /* Array */ === e.type), $(t, e, r);
            case "boolean" /* Boolean */ :
                return B("boolean" /* Boolean */ === e.type), G(t, e);
            case "color" /* Color */ :
                return B("color" /* Color */ === e.type), X(t, e);
            case "date" /* Date */ :
                return B("date" /* Date */ === e.type), Z(t, e);
            case "enum" /* Enum */ :
                return B("enum" /* Enum */ === e.type), tr(t, e);
            case "file" /* File */ :
                return B("file" /* File */ === e.type), ts(t, e);
            case "link" /* Link */ :
                return B("link" /* Link */ === e.type), tu(t, e);
            case "number" /* Number */ :
                return B("number" /* Number */ === e.type), tc(t, e);
            case "object" /* Object */ :
                return B("object" /* Object */ === e.type), tg(t, e, r);
            case "responsiveimage" /* ResponsiveImage */ :
                return B("responsiveimage" /* ResponsiveImage */ === e.type), tp(t, e);
            case "richtext" /* RichText */ :
                return B("richtext" /* RichText */ === e.type), tb(t, e);
            case "vectorsetitem" /* VectorSetItem */ :
                return B("vectorsetitem" /* VectorSetItem */ === e.type), tB(t, e);
            case "string" /* String */ :
                return B("string" /* String */ === e.type), tU(t, e, r);
            default:
                E(t);
        }
    };
})(r || (r = {})); // src/code-generation/components/cms/bundled/models/DatabaseDictionaryIndexModel.ts
var tE = class e {
        sortEntries() {
            this.entries.sort((t, e) => {
                for (let i = 0; i < this.fieldNames.length; i++) {
                    let n = t.values[i],
                        s = e.values[i],
                        o = r.compare(n, s, this.options.collation);
                    if (0 !== o) return o;
                }
                return t.pointer.compare(e.pointer);
            });
        }
        static async deserialize(t, i) {
            let n = new b(t),
                s = n.readJson(),
                o = n.readUint8(),
                a = [];
            for (let t = 0; t < o; t++) {
                let t = n.readString();
                a.push(t);
            }
            let u = new e(a, {
                    collation: s
                }),
                l = n.readUint32(),
                h = () => {
                    let t = [];
                    for (let e = 0; e < o; e++) {
                        let e = r.read(n);
                        t.push(e);
                    }
                    let e = R.read(n);
                    u.entries.push({
                        values: t,
                        pointer: e
                    });
                };
            for (let t = 0; t < l; t++) {
                let t = i ? .();
                t && await t, h();
            }
            return u;
        }
        serialize() {
            let t = new O;
            for (let e of (t.writeJson(this.options.collation), t.writeUint8(this.fieldNames.length), this.fieldNames)) t.writeString(e);
            for (let e of (this.sortEntries(), t.writeUint32(this.entries.length), this.entries)) {
                let {
                    values: i,
                    pointer: n
                } = e;
                for (let e of i) r.write(t, e);
                n.write(t);
            }
            return t.subarray();
        }
        addItem(t, e) {
            let r = this.fieldNames.map(e => t.getField(e) ? ? null);
            this.entries.push({
                values: r,
                pointer: e
            });
        }
        constructor(e, r) {
            t(this, "fieldNames", void 0), t(this, "options", void 0), t(this, "entries", []), this.fieldNames = e, this.options = r;
        }
    },
    tM = 3,
    tP = 250,
    tT = [408, // Request Timeout
        429, // Too Many Requests
        500, // Internal Server Error
        502, // Bad Gateway
        503, // Service Unavailable
        504
    ],
    tx = async (t, e) => {
        let r = 0;
        for (;;) {
            try {
                let i = await fetch(t, e);
                if (!tT.includes(i.status) || ++r > tM) return i;
            } catch (t) {
                if (e ? .signal ? .aborted || ++r > tM) throw t;
            }
            await tF(r);
        }
    };
async function tF(t) {
    let e = Math.floor(tP * (Math.random() + 1) * 2 ** (t - 1));
    await new Promise(t => {
        setTimeout(t, e);
    });
} // src/code-generation/components/cms/bundled/rangeRequest.ts
async function tN(t, e) {
    let r = tO(e),
        i = [],
        n = 0;
    for (let t of r) i.push(`${t.from}-${t.to-1}`), n += t.to - t.from;
    let s = new URL(t),
        o = i.join(",");
    s.searchParams.set("range", o);
    let a = await tx(s);
    if (200 !== a.status) throw Error(`Request failed: ${a.status} ${a.statusText}`);
    let u = await a.arrayBuffer(),
        l = new Uint8Array(u);
    if (l.length !== n) throw Error("Request failed: Unexpected response length");
    let h = new tA,
        c = 0;
    for (let t of r) {
        let e = t.to - t.from,
            r = c + e,
            i = l.subarray(c, r);
        h.write(t.from, i), c = r;
    }
    return e.map(t => h.read(t.from, t.to - t.from));
}
var tA = class {
    read(t, e) {
        for (let r of this.chunks) {
            if (t < r.start) break;
            if (t > r.end) continue;
            if (t + e > r.end) break;
            let i = t - r.start,
                n = i + e;
            return r.data.slice(i, n);
        }
        throw Error("Missing data");
    }
    write(t, e) {
        let r = t,
            i = r + e.length,
            n = 0,
            s = this.chunks.length;
        for (; n < s; n++) {
            let t = this.chunks[n];
            if (B(t, "Missing chunk"), !(r > t.end)) {
                if (r > t.start) {
                    let i = r - t.start,
                        n = t.data.subarray(0, i);
                    e = tq(n, e), r = t.start;
                }
                break;
            }
        }
        for (; s > n; s--) {
            let t = this.chunks[s - 1];
            if (B(t, "Missing chunk"), !(i < t.start)) {
                if (i < t.end) {
                    let r = i - t.start,
                        n = t.data.subarray(r);
                    e = tq(e, n), i = t.end;
                }
                break;
            }
        }
        let o = {
                start: r,
                end: i,
                data: e
            },
            a = s - n;
        this.chunks.splice(n, a, o);
    }
    constructor() {
        t(this, "chunks", []);
    }
};

function tq(t, e) {
    let r = t.length + e.length,
        i = new Uint8Array(r);
    return i.set(t, 0), i.set(e, t.length), i;
}

function tO(t) {
    B(t.length > 0, "Must have at least one range");
    let e = [...t].sort((t, e) => t.from - e.from),
        r = [];
    for (let t of e) {
        let e = r.length - 1,
            i = r[e];
        i && t.from <= i.to ? r[e] = {
            from: i.from,
            to: Math.max(i.to, t.to)
        } : r.push(t);
    }
    return r;
} // src/code-generation/components/cms/bundled/DatabaseDictionaryIndex.ts
var t_ = class {
    async loadModel() {
        let [t] = await tN(this.options.url, [this.options.range]);
        return B(t, "Failed to load model"), tE.deserialize(t, () => {
            let t = m(this.modelPrioritySources);
            return t ? U({
                batch: !0,
                priority: t
            }) : void 0;
        });
    }
    async getModel(t) {
        return this.model || (t && this.modelPrioritySources.add(t), this.modelPromise ? ? = this.loadModel().finally(() => {
            this.modelPrioritySources.clear();
        }), this.model ? ? = await this.modelPromise), this.model;
    }
    async lookupItems(t, e) {
        B(t.length === this.fields.length, "Invalid query length");
        let r = await this.getModel(e),
            i = [r.entries];
        for (let [r, n] of t.entries()) {
            let t = [];
            for (let s of i) {
                let i;
                let o = e ? U({
                    batch: !0,
                    priority: v(e)
                }) : void 0;
                switch (o && await o, n.type) {
                    case "All" /* All */ :
                        i = [s];
                        break;
                    case "Equals" /* Equals */ :
                        i = this.queryEquals(s, n, r);
                        break;
                    case "NotEquals" /* NotEquals */ :
                        i = this.queryNotEquals(s, n, r);
                        break;
                    case "LessThan" /* LessThan */ :
                        i = this.queryLessThan(s, n, r);
                        break;
                    case "GreaterThan" /* GreaterThan */ :
                        i = this.queryGreaterThan(s, n, r);
                        break;
                    case "Contains" /* Contains */ :
                        i = await this.queryContains(s, n, r, e);
                        break;
                    case "StartsWith" /* StartsWith */ :
                        i = await this.queryStartsWith(s, n, r, e);
                        break;
                    case "EndsWith" /* EndsWith */ :
                        i = await this.queryEndsWith(s, n, r, e);
                        break;
                    default:
                        E(n);
                }
                t.push(...i);
            }
            i = t;
        }
        let n = [];
        for (let t of i)
            for (let r of t) {
                let t = e ? U({
                    batch: !0,
                    priority: v(e)
                }) : void 0;
                t && await t;
                let i = {};
                for (let t = 0; t < this.options.fieldNames.length; t++) {
                    let e = this.options.fieldNames[t],
                        n = r.values[t];
                    i[e] = n;
                }
                n.push({
                    pointer: r.pointer.toString(),
                    data: i
                });
            }
        return n;
    }
    queryEquals(t, e, r) {
        let i = this.getLeftMost(t, r, e.value),
            n = this.getRightMost(t, r, e.value),
            s = t.slice(i, n + 1);
        return s.length > 0 ? [s] : [];
    }
    queryNotEquals(t, e, r) {
        let i = this.getLeftMost(t, r, e.value),
            n = this.getRightMost(t, r, e.value),
            s = [],
            o = t.slice(0, i);
        o.length > 0 && s.push(o);
        let a = t.slice(n + 1);
        return a.length > 0 && s.push(a), s;
    }
    queryLessThan(t, e, r) {
        let i = this.getRightMost(t, r, null);
        if (t = t.slice(i + 1), e.inclusive) {
            let i = this.getRightMost(t, r, e.value),
                n = t.slice(0, i + 1);
            return n.length > 0 ? [n] : [];
        }
        let n = this.getLeftMost(t, r, e.value),
            s = t.slice(0, n);
        return s.length > 0 ? [s] : [];
    }
    queryGreaterThan(t, e, r) {
        let i = this.getRightMost(t, r, null);
        if (t = t.slice(i + 1), e.inclusive) {
            let i = this.getLeftMost(t, r, e.value),
                n = t.slice(i);
            return n.length > 0 ? [n] : [];
        }
        let n = this.getRightMost(t, r, e.value),
            s = t.slice(n + 1);
        return s.length > 0 ? [s] : [];
    }
    queryContains(t, e, r, i) {
        return this.findItems(t, r, i, t => {
            if (t ? .type !== S.String || e.value ? .type !== S.String) return !1;
            let r = t.value,
                i = e.value.value;
            return 0 /* CaseInsensitive */ === this.collation.type && (r = r.toLowerCase(), i = i.toLowerCase()), r.includes(i);
        });
    }
    queryStartsWith(t, e, r, i) {
        return this.findItems(t, r, i, t => {
            if (t ? .type !== S.String || e.value ? .type !== S.String) return !1;
            let r = t.value,
                i = e.value.value;
            return 0 /* CaseInsensitive */ === this.collation.type && (r = r.toLowerCase(), i = i.toLowerCase()), r.startsWith(i);
        });
    }
    queryEndsWith(t, e, r, i) {
        return this.findItems(t, r, i, t => {
            if (t ? .type !== S.String || e.value ? .type !== S.String) return !1;
            let r = t.value,
                i = e.value.value;
            return 0 /* CaseInsensitive */ === this.collation.type && (r = r.toLowerCase(), i = i.toLowerCase()), r.endsWith(i);
        });
    }
    /**
     * Returns the index of the left most entry that is equal to the target.
     *
     * ```text
     *   Left most
     *       ↓
     * ┌───┬───┬───┬───┬───┬───┐
     * │ 1 │ 2 │ 2 │ 2 │ 2 │ 3 │
     * └───┴───┴───┴───┴───┴───┘
     * ```
     *
     * @param entries The entries array to search in.
     * @param position The position of the value in the entry.
     * @param target The target value to search for.
     * @returns The index of the left most entry that is equal to the target.
     */
    getLeftMost(t, e, i) {
        let n = 0,
            s = t.length;
        for (; n < s;) {
            let o = n + s >> 1,
                a = t[o],
                u = a.values[e];
            0 > r.compare(u, i, this.collation) ? n = o + 1 : s = o;
        }
        return n;
    }
    /**
     * Returns the index of the right most entry that is equal to the target.
     *
     * ```text
     *              Right most
     *                   ↓
     * ┌───┬───┬───┬───┬───┬───┐
     * │ 1 │ 2 │ 2 │ 2 │ 2 │ 3 │
     * └───┴───┴───┴───┴───┴───┘
     * ```
     *
     * @param entries The entries array to search in.
     * @param position The position of the value in the entry.
     * @param target The target value to search for.
     * @returns The index of the right most entry that is equal to the target.
     */
    getRightMost(t, e, i) {
        let n = 0,
            s = t.length;
        for (; n < s;) {
            let o = n + s >> 1,
                a = t[o],
                u = a.values[e];
            r.compare(u, i, this.collation) > 0 ? s = o : n = o + 1;
        }
        return s - 1;
    }
    /**
     * Finds all items that are matching the predicate and groups adjacent items together.
     *
     * @param entries The entries array to search in.
     * @param position The position of the value in the entry.
     * @param predicate The predicate to match the values against.
     * @returns An array of chunks that match the predicate.
     */
    async findItems(t, e, r, i) {
        let n = [],
            s = 0;
        for (let o = 0; o < t.length; o++) {
            let a = r ? U({
                batch: !0,
                priority: v(r)
            }) : void 0;
            a && await a;
            let u = t[o],
                l = u.values[e],
                h = i(l);
            if (!h) {
                if (s < o) {
                    let e = t.slice(s, o);
                    n.push(e);
                }
                s = o + 1;
            }
        }
        if (s < t.length) {
            let e = t.slice(s);
            n.push(e);
        }
        return n;
    }
    constructor(e) {
        t(this, "options", void 0), t(this, "schema", void 0), t(this, "fields", void 0), t(this, "supportedLookupTypes", ["All" /* All */ , "Equals" /* Equals */ , "NotEquals" /* NotEquals */ , "LessThan" /* LessThan */ , "GreaterThan" /* GreaterThan */ , "Contains" /* Contains */ , "StartsWith" /* StartsWith */ , "EndsWith" /* EndsWith */ ]), t(this, "modelPromise", void 0), t(this, "model", void 0), t(this, "modelPrioritySources", /* @__PURE__ */ new Set), t(this, "collation", void 0), this.options = e;
        let r = {},
            i = [];
        for (let t of this.options.fieldNames) {
            let e = this.options.collectionSchema[t];
            B(e, "Missing definition for field", t), r[t] = e, i.push({
                type: "Identifier",
                name: t
            });
        }
        this.schema = r, this.fields = i, this.collation = this.options.collation;
    }
}; // src/code-generation/components/cms/bundled/models/DatabaseItemModel.ts
function tj(t) {
    let e = {},
        i = t.readUint16();
    for (let n = 0; n < i; n++) {
        let i = t.readString();
        e[i] = r.read(t);
    }
    return e;
} // src/code-generation/components/cms/bundled/DatabaseCollection.ts?bundle
function* tD(t) {
    for (let e of t) yield* e.prioritySources;
}
var tR = class {
        scanItems(t) {
            return this.itemsPromise ? this.isScanning && t && this.scanPrioritySources.add(t) : (this.isScanning = !0, t && this.scanPrioritySources.add(t), this.itemsPromise = tx(this.url).then(async t => {
                if (!t.ok) throw Error(`Request failed: ${t.status} ${t.statusText}`);
                let e = await t.arrayBuffer(),
                    r = new Uint8Array(e),
                    i = new b(r),
                    n = [],
                    s = i.readUint32();
                for (let t = 0; t < s; t++) {
                    let t = m(this.scanPrioritySources),
                        e = t ? g({
                            batch: !0,
                            priority: t
                        }) : void 0;
                    e && await e;
                    let r = i.getOffset(),
                        s = tj(i),
                        o = i.getOffset() - r,
                        a = new R(this.id, r, o),
                        u = a.toString(),
                        l = {
                            pointer: u,
                            data: s
                        };
                    this.itemLoader.prime({
                        pointer: u,
                        prioritySources: /* @__PURE__ */ new Set
                    }, l), n.push(l);
                }
                return n;
            }).finally(() => {
                this.isScanning = !1, this.scanPrioritySources.clear();
            })), this.itemsPromise;
        }
        resolveItem(t, e) {
            let r = this.itemPrioritySources.get(t);
            r || (r = /* @__PURE__ */ new Set, this.itemPrioritySources.set(t, r)), e && r.add(e);
            let i = this.itemLoader.load({
                    pointer: t,
                    prioritySources: r
                }),
                n = () => this.itemPrioritySources.delete(t);
            return i.then(n, n), i;
        }
        constructor(e, r) {
            t(this, "id", void 0), t(this, "url", void 0), t(this, "itemsPromise", void 0), t(this, "isScanning", !1), t(this, "scanPrioritySources", /* @__PURE__ */ new Set), t(this, "itemPrioritySources", /* @__PURE__ */ new Map), t(this, "itemLoader", new d.default(async t => {
                let e = t.map(({
                        pointer: t
                    }) => {
                        let e = R.fromString(t);
                        return {
                            from: e.offset,
                            to: e.offset + e.length
                        };
                    }),
                    r = await tN(this.url, e),
                    i = [];
                for (let e = 0; e < r.length; e++) {
                    let n = m(tD(t)),
                        s = n ? g({
                            batch: !0,
                            priority: n
                        }) : void 0;
                    s && await s;
                    let o = r[e];
                    B(o, "Missing range bytes");
                    let a = new b(o),
                        u = tj(a),
                        l = t[e] ? .pointer;
                    B(l, "Missing pointer"), i.push({
                        pointer: l,
                        data: u
                    });
                }
                return i;
            }, { // capping to 250 avoids overly long URLs that can cause requests to fail with 414
                maxBatchSize: 250, // Different route workflows can request the same item. Keep DataLoader's cache keyed by the
                // pointer while still carrying the strongest scheduling priority into the shared batch
                cacheKeyFn: t => t.pointer
            })), this.id = e, this.url = r;
        }
    },
    tC = class {
        async scanItems(t) {
            let e = await Promise.all(this.chunks.map(async e => e.scanItems(t)));
            return e.flat();
        }
        resolveItems(t, e) {
            return Promise.all(t.map(t => {
                let r = R.fromString(t),
                    i = this.chunks[r.chunkId];
                return B(i, "Missing chunk"), i.resolveItem(t, e);
            }));
        }
        compareItems(t, e) {
            let r = R.fromString(t.pointer),
                i = R.fromString(e.pointer);
            return r.compare(i);
        }
        compareValues(t, e, i) {
            return r.compare(t, e, i);
        }
        constructor(e) {
            t(this, "options", void 0), t(this, "id", void 0), t(this, "schema", void 0), t(this, "indexes", void 0), t(this, "resolveRichText", void 0), t(this, "resolveVectorSetItem", void 0), t(this, "chunks", void 0), this.options = e, this.chunks = this.options.chunks.map((t, e) => new tR(e, t)), this.schema = e.schema, this.indexes = e.indexes, this.resolveRichText = e.resolveRichText, this.resolveVectorSetItem = e.resolveVectorSetItem, this.id = e.id;
        }
    };
export {
    tC as DatabaseCollection, t_ as DatabaseDictionaryIndex
};
export const __FramerMetadata__ = {
    "exports": {
        "DatabaseDictionaryIndex": {
            "type": "variable",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "DatabaseCollection": {
            "type": "variable",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "__FramerMetadata__": {
            "type": "variable"
        }
    }
}