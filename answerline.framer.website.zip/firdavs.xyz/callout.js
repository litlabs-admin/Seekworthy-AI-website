(function() {
    "use strict";
    const W = Object.freeze({
        buy: "callout-buy-clicked",
        claim: "callout-claim-clicked",
        "get-free": "callout-get-free-clicked",
        "see-all": "callout-see-all-clicked",
        site: "callout-site-clicked"
    });

    function te(e, {
        config: t,
        getPageContext: s,
        isOptedOut: p = () => !1,
        fetchImpl: n = (...u) => fetch(...u)
    }) {
        const u = {
            template: e.slug,
            offer: e.paid ? "full" : "free",
            country: "unknown",
            currency: "USD",
            base_price: e.price,
            price: e.price,
            discount_percent: 0
        };
        let r = null,
            c = null,
            k = !1,
            b;
        const S = new Promise(a => {
            b = a
        });
        async function $(a) {
            try {
                const l = {
                    "Content-Type": "application/json"
                };
                r && (l["x-umami-cache"] = r);
                const w = await n(t.endpoint, {
                        method: "POST",
                        keepalive: !0,
                        headers: l,
                        body: JSON.stringify({
                            type: "event",
                            payload: {
                                website: t.websiteId,
                                ...s(),
                                ...a
                            }
                        })
                    }),
                    A = w.ok ? await w.json() : null;
                A != null && A.cache && (r = A.cache)
            } catch {}
        }

        function x(a) {
            return !t || p() ? Promise.resolve() : c ? c.then(() => $(a)) : (c = $(a), c)
        }

        function g(a, l = {}) {
            return S.then(() => x({
                name: a,
                data: { ...u,
                    ...l
                }
            }))
        }
        return {
            setPricing(a) {
                var l;
                k || !a || Object.assign(u, {
                    offer: ((l = a.offer) == null ? void 0 : l.type) === "launch" ? "launch" : a.tier || "full",
                    country: a.country || "unknown",
                    currency: a.currency,
                    base_price: a.basePrice,
                    price: a.price,
                    discount_percent: a.discountPercent
                })
            },
            pageview() {
                return x({})
            },
            seen(a) {
                if (k) return Promise.resolve();
                k = !0, a && (u.offer = a);
                const l = x({
                    name: "callout-seen",
                    data: { ...u
                    }
                });
                return b(), l
            },
            event: g,
            click(a) {
                const l = [g("callout-click", {
                    target: a
                })];
                return Object.hasOwn(W, a) && l.push(g(W[a], {
                    target: a
                })), Promise.all(l)
            }
        }
    }

    function ae(e, t) {
        switch (t.kind) {
            case "launch":
                {
                    const s = `${t.remaining} left`;
                    return [{
                        label: `${e} free for the first ${t.limit}`,
                        chip: s
                    }, {
                        label: `Free for the first ${t.limit}`,
                        chip: s
                    }, {
                        label: "Free",
                        chip: s
                    }]
                }
            case "regional":
                {
                    const s = `${t.discountPercent}% off`;
                    return [{
                        label: `${e} for ${t.price}`,
                        chip: s
                    }, {
                        label: `Now ${t.price}`,
                        chip: s
                    }, {
                        label: t.price,
                        chip: s
                    }]
                }
            case "free":
                return [{
                    label: `Get ${e} free`,
                    chip: "Free"
                }, {
                    label: "Get it free",
                    chip: null
                }, {
                    label: "Free",
                    chip: null
                }];
            default:
                return [{
                    label: `Get ${e} for ${t.price}`,
                    chip: null
                }, {
                    label: `Get it for ${t.price}`,
                    chip: null
                }, {
                    label: t.price,
                    chip: null
                }]
        }
    }
    const se = 480;

    function ie(e, {
        viewport: t,
        room: s,
        widthOf: p
    }) {
        for (let n = 0; n < e; n++)
            if (!(n === 0 && e > 1 && t < se) && p(n) <= s) return n;
        return e - 1
    }
    const _ = 8,
        q = 18;

    function re({
        viewport: e,
        viewportHeight: t,
        tabWidth: s,
        flare: p,
        badge: n
    }) {
        return !n || n.width === 0 || n.bottom < t - 120 ? {
            side: "center"
        } : e / 2 + s / 2 + p + _ <= n.left ? {
            side: "center"
        } : {
            side: "left",
            room: Math.max(0, n.left - _ - p - q)
        }
    }
    var ne = {
        origin: "https://firdavs.xyz",
        analytics: {
            endpoint: "https://analytics.firdavs.xyz/api/send",
            websiteId: "3d47b3b9-b2ac-477e-876e-23c1f06767cc"
        },
        portrait: {
            idle: "https://firdavs.xyz/brand/portrait/idle-tile.svg"
        },
        font: "https://firdavs.xyz/fonts/SeasonMix-Regular.woff2",
        catalogUrl: "https://firdavs.xyz/templates#catalog",
        flagsUrl: "https://firdavs.xyz/flags/",
        showcase: [{
            slug: "waymark",
            src: "https://firdavs.xyz/images/framering/waymark/gallery-desktop-1.88e4e7e07a.webp"
        }, {
            slug: "firstcheck",
            src: "https://firdavs.xyz/images/framering/firstcheck/gallery-desktop-1.4ad0a5f6d0.webp"
        }, {
            slug: "upturn",
            src: "https://firdavs.xyz/images/framering/upturn/gallery-desktop-1.c650d7ea54.webp"
        }, {
            slug: "noted",
            src: "https://firdavs.xyz/images/framering/noted/gallery-desktop-1.4cc42514e2.webp"
        }],
        templates: [{
            slug: "departures",
            host: "departures.framer.website",
            name: "Departures",
            tagline: "Designer portfolio website",
            description: "Designer portfolio website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "8 pages",
                tags: ["Home", "Work", "+6"]
            }, {
                kind: "cms",
                label: "1 CMS collection",
                tags: ["Projects"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_sMbmIjgY04tCV7MUwuDvq7GMR8xG8RQw416BU1IHh2m"
        }, {
            slug: "tamp",
            host: "tamp-coffee.framer.website",
            name: "Tamp",
            tagline: "Coffee shop and café website",
            description: "Coffee shop and café website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "10 pages",
                tags: ["Home", "Menu", "+8"]
            }, {
                kind: "cms",
                label: "1 CMS collection",
                tags: ["Menu"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 29,
            priceLabel: "$29",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_Qm1seuBv16gyrDRBtN2WoN2rldHcmuIrLwlcg0HxRjQ"
        }, {
            slug: "byline",
            host: "byline-letter.framer.website",
            name: "Byline",
            tagline: "Newsletter and podcast website",
            description: "Newsletter and podcast website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "10 pages",
                tags: ["Home", "Library", "+8"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Issues", "Episodes"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_HRGFPIDP5wYY5Vx8GyRixOgWg4ggXKxXJ2IkV3cZN97"
        }, {
            slug: "bloop-ai",
            host: "bloop-ai.framer.website",
            name: "Bloop",
            tagline: "AI agent startup website",
            description: "AI agent startup website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "12 pages",
                tags: ["Home", "Agents", "+10"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Agents", "Case studies"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_w9CWEHF78XWhsJbaO1ZvFAYwQ4G1rsA2ujGty1zzzIs"
        }, {
            slug: "playframe",
            host: "playframe.framer.website",
            name: "Playframe",
            tagline: "Short-form video agency website",
            description: "Short-form video agency website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "12 pages",
                tags: ["Home", "Work", "+10"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Work", "Journal"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_OIJRYbqJXSvgO723kjlUR4FWxCyIRYc1jDRSn0BH21c"
        }, {
            slug: "rowe",
            host: "rowe-agent.framer.website",
            name: "Rowe",
            tagline: "Real estate agent website",
            description: "Real estate agent website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "12 pages",
                tags: ["Home", "Homes", "+10"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Homes", "Neighborhoods"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }, {
                kind: "tutorial",
                label: "Video tutorial",
                tags: ["11 min"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_UWdkXHjCRwneotQuUfQ6S2IQTLCrSSYNqDooC1BtGtG"
        }, {
            slug: "mosaic",
            host: "guilia-ferri.framer.website",
            name: "Mosaic",
            tagline: "Leadership coaching website",
            description: "Leadership coaching website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "10 pages",
                tags: ["Home", "Coaching", "+8"]
            }, {
                kind: "cms",
                label: "1 CMS collection",
                tags: ["Stories"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_38xAwPCYIVXTOHQRfgychau1TrxiYd5bbnTvR0mbeVw"
        }, {
            slug: "winrate",
            host: "winrate.framer.website",
            name: "Winrate",
            tagline: "Performance ads agency website",
            description: "Performance ads agency website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "12 pages",
                tags: ["Home", "Services", "+10"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Work", "Playbook"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_Po0XbUWlL9bLMyAAPbh9qsxSvhZhfp5RZGByO2sGJfg"
        }, {
            slug: "answerline",
            host: "answerline.framer.website",
            name: "Answerline",
            tagline: "AI search & SEO agency website",
            description: "AI search & SEO agency website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "13 pages",
                tags: ["Home", "Services", "+11"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Case studies", "Insights"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_FAcM2qzFrxTbAs6dzlqZJXT3BT3Sk9zJeO6le2WA27N"
        }, {
            slug: "ondeck",
            host: "ondeck-studio.framer.website",
            name: "OnDeck",
            tagline: "Design subscription studio website",
            description: "Design subscription studio website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "7 pages",
                tags: ["Home", "Work", "+5"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Work", "Legal"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_bcwKhvnDPMpbCfuiAgYcJ4w2lSDfvd4Opw0gZ1g2LnK"
        }, {
            slug: "twist",
            host: "twist.framer.wiki",
            name: "Twist",
            tagline: "Design subscription agency website",
            description: "Design subscription agency website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "7 pages",
                tags: ["Home", "Work", "+5"]
            }, {
                kind: "cms",
                label: "1 CMS collection",
                tags: ["Work"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_7pqi0MGdtqfg1sXGyYa6ZZF8gIDqcEu3yFlb61TOCqn"
        }, {
            slug: "keel",
            host: "keel-agency.framer.website",
            name: "Keel",
            tagline: "Strategy consulting website",
            description: "Strategy consulting website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "11 pages",
                tags: ["Home", "Services", "+9"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Case studies", "Insights"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 69,
            priceLabel: "$69",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_qi6wBhhipVOTTF4x6ST2cRCYhtyj8vjEnUrrI4FJmib"
        }, {
            slug: "canvasfolio",
            host: "ilse-moreno.framer.website",
            name: "Canvasfolio",
            tagline: "Portfolio with a draggable canvas",
            description: "Portfolio with a draggable canvas, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "5 pages",
                tags: ["Home", "Work", "+3"]
            }, {
                kind: "cms",
                label: "1 CMS collection",
                tags: ["Projects"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 69,
            priceLabel: "$69",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_9ULKzaRlOICSxqZ8SA4OJIO9UKRLSGT4KG9Ji0JB8Jt"
        }, {
            slug: "upturn",
            host: "upturn.framer.wiki",
            name: "Upturn",
            tagline: "Website for career change coaches",
            description: "Website for career change coaches, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "8 pages",
                tags: ["Home", "Stories", "+6"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Stories", "Legal"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 0,
            priceLabel: "Free",
            paid: !1,
            ctaUrl: "https://firdavs.xyz/templates/upturn?get=free"
        }, {
            slug: "pipewright",
            host: "pipewright.framer.website",
            name: "Pipewright",
            tagline: "Plumbing website with a price book",
            description: "Plumbing website with a price book, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "9 pages",
                tags: ["Home", "Services", "+7"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Services", "Price book"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 0,
            priceLabel: "Free",
            paid: !1,
            ctaUrl: "https://firdavs.xyz/templates/pipewright?get=free"
        }, {
            slug: "waymark",
            host: "waymark-coaching.framer.website",
            name: "Waymark",
            tagline: "Leadership coaching website",
            description: "Leadership coaching website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "7 pages",
                tags: ["Home", "Coaching", "+5"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Transitions", "Legal"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 69,
            priceLabel: "$69",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_lXk4QrqLd0o5PwhsSqU1V3UTRIQDdbFBxm3JG1uGCJk"
        }, {
            slug: "noted",
            host: "noted.framer.ai",
            name: "Noted",
            tagline: "AI receptionist website for clinics",
            description: "AI receptionist website for clinics, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "9 pages",
                tags: ["Home", "Pricing", "+7"]
            }, {
                kind: "cms",
                label: "2 CMS collections",
                tags: ["Clinic types", "Legal pages"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 69,
            priceLabel: "$69",
            paid: !0,
            ctaUrl: "https://contra.com/products/1wVWboqC-noted-framer-template-for-ai-receptionist-startups"
        }, {
            slug: "callwave",
            host: "callwave.framer.website",
            name: "CallWave",
            tagline: "Voice AI agent website",
            description: "Voice AI agent website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "7 pages",
                tags: ["Home", "Pricing", "+5"]
            }, {
                kind: "cms",
                label: "1 CMS collection",
                tags: ["Sample calls"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 69,
            priceLabel: "$69",
            paid: !0,
            ctaUrl: "https://contra.com/products/qFMtsw96-call-wave-framer-template-for-voice-ai-startups"
        }, {
            slug: "toolport",
            host: "toolport.framer.website",
            name: "Toolport",
            tagline: "MCP server & SDK launch website",
            description: "MCP server & SDK launch website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "9 pages",
                tags: ["Home", "Install", "+7"]
            }, {
                kind: "cms",
                label: "4 CMS collections",
                tags: ["Categories", "Articles", "+2"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 29,
            priceLabel: "$29",
            paid: !0,
            ctaUrl: "https://buy.polar.sh/polar_cl_dTtzstvc03gNQQv9nX8xD5kFSMdRXgNJyOBYC4SpskT"
        }, {
            slug: "firstcheck",
            host: "firstcheck.framer.ai",
            name: "FirstCheck",
            tagline: "Website for early-stage VC funds",
            description: "Website for early-stage VC funds, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "9 pages",
                tags: ["Home", "Portfolio", "+7"]
            }, {
                kind: "cms",
                label: "3 CMS collections",
                tags: ["Portfolio", "Team", "+1"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 69,
            priceLabel: "$69",
            paid: !0,
            ctaUrl: "https://contra.com/products/jkT26wRg-firstcheck-framer-template-for-vc-funds"
        }, {
            slug: "shiproom",
            host: "shiproom.framer.website",
            name: "Shiproom",
            tagline: "Live cohort course website",
            description: "Live cohort course website, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "2 pages",
                tags: ["Home", "404"]
            }, {
                kind: "cms",
                label: "1 CMS collection",
                tags: ["Weeks"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 19,
            priceLabel: "$19",
            paid: !0,
            ctaUrl: "https://contra.com/products/qs1sP7EK-shiproom-framer-cohort-course-template"
        }, {
            slug: "citebound",
            host: "citebound.framer.website",
            name: "Citebound",
            tagline: "AI Search, SEO, GEO agency site",
            description: "AI Search, SEO, GEO agency site, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "15 pages",
                tags: ["Home", "Audit", "+13"]
            }, {
                kind: "cms",
                label: "3 CMS collections",
                tags: ["Case studies", "Categories", "+1"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 69,
            priceLabel: "$69",
            paid: !0,
            ctaUrl: "https://contra.com/products/og7ykZoe-citebound-framer-template-for-ai-searchgeo-agencies"
        }, {
            slug: "nonlinear",
            host: "nonlinear.framer.website",
            name: "Nonlinear",
            tagline: "Dark SaaS template for AI startups",
            description: "Dark SaaS template for AI startups, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "11 pages",
                tags: ["Home", "Product", "+9"]
            }, {
                kind: "cms",
                label: "6 CMS collections",
                tags: ["Blog categories", "Blog posts", "+4"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 49,
            priceLabel: "$49",
            paid: !0,
            ctaUrl: "https://contra.com/products/uW4SIs17-nonlinear-framer-saa-s-template"
        }, {
            slug: "imaginate",
            host: "imaginate.framer.website",
            name: "Imaginate",
            tagline: "Template for AI image gen products",
            description: "Template for AI image gen products, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "4 pages",
                tags: ["Home", "Terms & conditions", "+2"]
            }, {
                kind: "cms",
                label: "1 CMS collection",
                tags: ["Legal"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 29,
            priceLabel: "$29",
            paid: !0,
            ctaUrl: "https://contra.com/products/Uq2Tu5op-imaginate-framer-template-for-ai-image-gen-products"
        }, {
            slug: "letterhead",
            host: "letterhead.framer.website",
            name: "Letterhead",
            tagline: "Website template for newsletters",
            description: "Website template for newsletters, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "9 pages",
                tags: ["Home", "Posts", "+7"]
            }, {
                kind: "cms",
                label: "1 CMS collection",
                tags: ["Posts"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 0,
            priceLabel: "Free",
            paid: !1,
            ctaUrl: "https://firdavs.xyz/templates/letterhead?get=free"
        }, {
            slug: "coursepro",
            host: "coursepro.framer.website",
            name: "CoursePro",
            tagline: "Online course template",
            description: "Online course template, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "12 pages",
                tags: ["Home", "About", "+10"]
            }, {
                kind: "cms",
                label: "4 CMS collections",
                tags: ["Modules", "Lessons", "+2"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 0,
            priceLabel: "Free",
            paid: !1,
            ctaUrl: "https://firdavs.xyz/templates/coursepro?get=free"
        }, {
            slug: "compound",
            host: "compound.framer.ai",
            name: "Compound",
            tagline: "AI & SaaS startup landing page",
            description: "AI & SaaS startup landing page, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "2 pages",
                tags: ["Home", "404"]
            }, {
                kind: "cms",
                label: "1 CMS collection",
                tags: ["Legal"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 0,
            priceLabel: "Free",
            paid: !1,
            ctaUrl: "https://firdavs.xyz/templates/compound?get=free"
        }, {
            slug: "convert",
            host: "convertai.framer.website",
            name: "Convert",
            tagline: "SaaS & tech startup template",
            description: "SaaS & tech startup template, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "18 pages",
                tags: ["Home", "Features", "+16"]
            }, {
                kind: "cms",
                label: "10 CMS collections",
                tags: ["Blogs", "Blog Authors", "+8"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 0,
            priceLabel: "Free",
            paid: !1,
            ctaUrl: "https://firdavs.xyz/templates/convert?get=free"
        }, {
            slug: "apiflow",
            host: "apiflow.framer.website",
            name: "ApiFlow",
            tagline: "Site & docs for API companies",
            description: "Site & docs for API companies, ready to remix into your Framer account.",
            included: [{
                kind: "pages",
                label: "14 pages",
                tags: ["Home", "Pricing", "+12"]
            }, {
                kind: "cms",
                label: "5 CMS collections",
                tags: ["Testimonials", "Docs", "+3"]
            }, {
                kind: "skills",
                label: "11 AI skills",
                tags: ["/design-system", "+10"]
            }],
            price: 0,
            priceLabel: "Free",
            paid: !1,
            ctaUrl: "https://firdavs.xyz/templates/apiflow?get=free"
        }]
    };
    const f = ne,
        U = document.currentScript,
        E = 12,
        H = 380,
        h = 14,
        B = 2 * h + 16,
        j = 44,
        N = "FirdavsSeasonMix",
        le = 1500,
        oe = 15e3,
        ce = 2e3,
        de = 4e3;

    function pe() {
        const e = location.hostname.replace(/^www\./, "").toLowerCase(),
            t = f.templates.find(s => s.host === e);
        if (t) return t;
        if (e === "localhost" || e === "127.0.0.1") {
            const s = new URLSearchParams(location.search).get("firdavs-callout") || (U == null ? void 0 : U.dataset.template);
            return f.templates.find(p => p.slug === s) || null
        }
        return null
    }

    function z(e) {
        return {
            get(t) {
                try {
                    return window[e].getItem(t)
                } catch {
                    return null
                }
            },
            set(t, s) {
                try {
                    window[e].setItem(t, s)
                } catch {}
            }
        }
    }

    function d(e) {
        return String(e).replace(/[&<>"']/g, t => `&#${t.charCodeAt(0)};`)
    }

    function O(e, t) {
        if (!e.startsWith(f.origin)) return e;
        const s = new URL(e);
        return s.searchParams.set("utm_source", "template-callout"), s.searchParams.set("utm_content", t), s.href
    }

    function ue() {
        if (document.getElementById("firdavs-callout-font")) return;
        const e = document.createElement("style");
        e.id = "firdavs-callout-font", e.textContent = `@font-face{font-family:${N};src:url(${f.font}) format("woff2");font-weight:400;font-display:swap}`, document.head.appendChild(e)
    }
    const G = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3.5 8h9m0 0-4-4m4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        ge = '<svg class="chev" width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 10l4-4 4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        fe = Object.fromEntries(Object.entries({
            pages: "M4.5 2A1.5 1.5 0 0 0 3 3.5v13A1.5 1.5 0 0 0 4.5 18h11a1.5 1.5 0 0 0 1.5-1.5V7.621a1.5 1.5 0 0 0-.44-1.06l-4.12-4.122A1.5 1.5 0 0 0 11.378 2H4.5Zm2.25 8.5a.75.75 0 0 0 0 1.5h6.5a.75.75 0 0 0 0-1.5h-6.5Zm0 3a.75.75 0 0 0 0 1.5h6.5a.75.75 0 0 0 0-1.5h-6.5Z",
            cms: "M10 1c3.866 0 7 1.79 7 4s-3.134 4-7 4-7-1.79-7-4 3.134-4 7-4Zm5.694 8.13c.464-.264.91-.583 1.306-.952V10c0 2.21-3.134 4-7 4s-7-1.79-7-4V8.178c.396.37.842.688 1.306.953C5.838 10.006 7.854 10.5 10 10.5s4.162-.494 5.694-1.37ZM3 13.179V15c0 2.21 3.134 4 7 4s7-1.79 7-4v-1.822c-.396.37-.842.688-1.306.953-1.532.875-3.548 1.369-5.694 1.369s-4.162-.494-5.694-1.37A7.009 7.009 0 0 1 3 13.179Z",
            skills: "M15.98 1.804a1 1 0 0 0-1.96 0l-.24 1.192a1 1 0 0 1-.784.785l-1.192.238a1 1 0 0 0 0 1.962l1.192.238a1 1 0 0 1 .785.785l.238 1.192a1 1 0 0 0 1.962 0l.238-1.192a1 1 0 0 1 .785-.785l1.192-.238a1 1 0 0 0 0-1.962l-1.192-.238a1 1 0 0 1-.785-.785l-.238-1.192ZM6.949 5.684a1 1 0 0 0-1.898 0l-.683 2.051a1 1 0 0 1-.633.633l-2.051.683a1 1 0 0 0 0 1.898l2.051.684a1 1 0 0 1 .633.632l.683 2.051a1 1 0 0 0 1.898 0l.683-2.051a1 1 0 0 1 .633-.633l2.051-.683a1 1 0 0 0 0-1.898l-2.051-.683a1 1 0 0 1-.633-.633L6.95 5.684ZM13.949 13.684a1 1 0 0 0-1.898 0l-.184.551a1 1 0 0 1-.632.633l-.551.183a1 1 0 0 0 0 1.898l.551.183a1 1 0 0 1 .633.633l.183.551a1 1 0 0 0 1.898 0l.184-.551a1 1 0 0 1 .632-.633l.551-.183a1 1 0 0 0 0-1.898l-.551-.184a1 1 0 0 1-.633-.632l-.183-.551Z",
            tutorial: "M6.3 2.84A1.5 1.5 0 0 0 4 4.11v11.78a1.5 1.5 0 0 0 2.3 1.27l9.344-5.891a1.5 1.5 0 0 0 0-2.538L6.3 2.841Z"
        }).map(([e, t]) => [e, `<svg width="15" height="15" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="${t}"/></svg>`])),
        he = '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true"><path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',
        me = `
:host{all:initial;position:fixed;left:0;right:0;bottom:0;display:flex;justify-content:center;z-index:2147483000;pointer-events:none;
  --ink:#0B0B0B;--body:#2A2A28;--muted:#6B6B66;--rule:#E6E6E3;--surface:#F4F4F2;--tile:#F1F1F0;--blue:#1D3BF0;
  --sky:#E9EDFF;--display:${N},"Season Mix",Georgia,serif;
  --ease:cubic-bezier(.32,.72,0,1);font-family:var(--display);font-weight:400;-webkit-font-smoothing:antialiased;color:var(--ink)}
*,*::before,*::after{box-sizing:border-box;margin:0;font-weight:400}
a{color:inherit;text-decoration:none}
button{font:inherit;color:inherit;background:none;border:0;padding:0;cursor:pointer;text-align:left}
:focus-visible{outline:2px solid var(--blue);outline-offset:3px}
[hidden]{display:none!important}

/* One shadow for tab, corners and folder: a crisp edge plus a lift, so white still
   reads as a separate surface on white templates. */
.dock{display:flex;flex-direction:column;align-items:center;
  filter:drop-shadow(0 0 .5px rgba(11,11,11,.4)) drop-shadow(0 -2px 6px rgba(11,11,11,.08)) drop-shadow(0 -10px 28px rgba(11,11,11,.14))}

.tab{pointer-events:auto;position:relative;display:flex;flex-direction:column;min-height:${j}px;padding:8px 14px 8px 8px;background:#fff;border-radius:14px 14px 0 0;
  transform:translateY(0);transition:transform 220ms var(--ease)}
.tab::before,.tab::after{content:"";position:absolute;bottom:0;width:${h}px;height:${h}px;pointer-events:none}
.tab::before{left:-${h}px;background:radial-gradient(circle at 0 0,transparent ${h-.5}px,#fff ${h}px)}
.tab::after{right:-${h}px;background:radial-gradient(circle at 100% 0,transparent ${h-.5}px,#fff ${h}px)}
.row{display:flex;align-items:center;gap:10px;min-height:28px}
.face{width:28px;height:28px;border-radius:8px;flex-shrink:0;background:var(--tile)}
.names{display:flex;flex-direction:column;min-width:0;flex:1}
.t-name{display:none;font-size:16px;line-height:20px;letter-spacing:-.01em}
.label{font-size:16px;line-height:20px;letter-spacing:-.01em;white-space:nowrap}
.chip{flex-shrink:0;padding:1px 8px;border-radius:999px;background:var(--sky);color:var(--blue);font-size:13px;line-height:18px;letter-spacing:.01em;white-space:nowrap}
.chev{flex-shrink:0;transition:transform 220ms var(--ease)}
@media (hover:hover){:host(:not([data-open])) .tab:hover{transform:translateY(-2px)}}

/* Teaser: the tab grows upward to show proof of the offer. */
/* The proof never widens the tab: it wraps to whatever width the tab already has. */
.reveal{display:grid;grid-template-rows:0fr;contain:inline-size;transition:grid-template-rows 360ms var(--ease)}
.reveal>span{min-height:0;overflow:hidden}
.proof{display:flex;flex-direction:column;gap:8px;padding:10px 12px;border-radius:10px;background:var(--sky);font-size:15px;line-height:20px;letter-spacing:.01em}
.proof-wrap{display:block;padding:12px 0 8px}
.proof-head{display:flex;justify-content:space-between;gap:12px}
.proof-head span:last-child{color:var(--blue)}
.proof .bar{display:flex;gap:2px}
.proof .bar i{flex:1;height:12px;border-radius:2px;background:rgba(29,59,240,.2)}
.proof .bar i[data-left]{background:var(--blue)}
.proof-price{display:flex;align-items:center;gap:8px;font-size:14px;line-height:18px}
.proof-price s{font-size:18px;line-height:22px;text-decoration:line-through 1px}
.proof-price b{font-size:18px;line-height:22px;letter-spacing:-.02em;color:var(--blue)}
.proof-price .flag{width:21px;height:14px}
:host([data-teaser]:not([data-open])) .tab{min-width:min(372px,calc(100vw - ${B}px))}
:host([data-teaser]:not([data-open])) .reveal{grid-template-rows:1fr}
/* With the name dropped from the tab, the teaser brings it back as the first line. */
:host([data-teaser]:not([data-fit="0"])) .t-name{display:block}
:host([data-teaser]:not([data-fit="0"])) .label{font-size:14px;line-height:18px}
:host([data-teaser]) .row .chip{display:none}

/* Beside Framer's badge: the tab hugs the left edge and the teaser keeps to the room left. */
:host([data-side="left"]) .dock{align-items:flex-start}
:host([data-side="left"]) .tab{margin-left:calc(${q}px - (100vw - var(--panel-w,${H}px)) / 2)}
:host([data-side="left"][data-teaser]:not([data-open])) .tab{min-width:0;width:var(--tab-room)}
/* Open, the tab moves in past the folder's rounded corner so its inverse corners sit on the edge. */
:host([data-side="left"][data-open]) .tab{margin-left:${20+h}px}
:host([data-side="left"][data-teaser]) .proof-head span:first-child{display:none}

/* Open: the tab becomes the folder's handle, just your face and a close arrow. */
:host([data-open]) .names,:host([data-open]) .chip,:host([data-open]) .reveal{display:none}
:host([data-open]) .chev{transform:rotate(180deg)}

.sheet{pointer-events:auto;width:var(--panel-w,${H}px);height:0;overflow:hidden;background:#fff;border-radius:20px 20px 0 0;visibility:hidden;
  transition:height 420ms var(--ease),visibility 0s linear 420ms}
:host([data-open]) .sheet{height:var(--panel-h);visibility:visible;transition:height 420ms var(--ease),visibility 0s}
.content{display:flex;flex-direction:column;height:var(--panel-h);padding-bottom:var(--badge-space,0px);opacity:0;transform:translateY(8px);transition:opacity 100ms ease-in,transform 100ms ease-in}
:host([data-open]) .content{opacity:1;transform:none;transition:opacity 180ms ease-out 120ms,transform 180ms ease-out 120ms}
.scroll{flex:1;min-height:0;overflow-y:auto;overscroll-behavior:contain}

.product{display:flex;flex-direction:column;gap:16px;padding:24px 20px}
.product-head{display:flex;justify-content:space-between;align-items:center;gap:16px}
.product-head h2{font-size:28px;line-height:32px;letter-spacing:-.035em}
.price-tag{display:flex;align-items:baseline;gap:8px;flex-shrink:0}
.price{font-size:28px;line-height:32px;letter-spacing:-.035em}
.list-price{font-size:17px;line-height:22px;color:var(--muted);text-decoration:line-through 1px}
.pill{padding:4px 12px;border-radius:999px;background:var(--sky);color:var(--blue);font-size:15px;line-height:22px;align-self:center}
.desc{font-size:15px;line-height:24px;letter-spacing:.01em;color:var(--body)}

.included{display:flex;flex-direction:column;padding:0 0 10px;list-style:none}
.included li{display:flex;align-items:flex-start;gap:10px;padding:8px 0;border-bottom:1px solid var(--rule)}
.included li:first-child{padding-top:0}
.included li:last-child{padding-bottom:0;border-bottom:0}
.inc-icon{display:grid;place-items:center;flex-shrink:0;width:26px;height:26px;border-radius:7px;background:var(--sky);color:var(--blue)}
.inc-label{flex-shrink:0;padding-top:3px;font-size:15px;line-height:20px;letter-spacing:.01em;white-space:nowrap}
.inc-tags{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:4px;flex:1;min-width:0;padding-top:2px}
.inc-tag{padding:2px 7px;border-radius:6px;background:var(--surface);font-size:13px;line-height:18px;letter-spacing:.01em;color:var(--body);white-space:nowrap}

.flag{width:24px;height:16px;flex-shrink:0;border-radius:3px;box-shadow:0 0 0 1px rgba(11,11,11,.1)}
.offer-regional{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:12px;background:var(--surface)}
.offer-regional div{display:flex;flex-direction:column;gap:1px;min-width:0}
.offer-title{font-size:15px;line-height:20px;letter-spacing:.01em}
.offer-sub{font-size:13px;line-height:18px;letter-spacing:.01em;color:var(--muted)}
.offer-launch{display:flex;flex-direction:column;gap:12px;padding:14px;border-radius:12px;background:var(--sky)}
.offer-launch-head{display:flex;justify-content:space-between;align-items:baseline;gap:12px}
.offer-left{font-size:15px;line-height:20px;letter-spacing:.01em;color:var(--blue)}
.bar{display:flex;gap:2px}
.bar i{flex:1;height:14px;border-radius:2px;background:rgba(29,59,240,.18)}
.bar i[data-left]{background:var(--blue)}

.cta{display:flex;align-items:center;justify-content:center;gap:8px;height:48px;border-radius:999px;font-size:17px;line-height:22px;color:#fff;transition:background-color 160ms}
.cta-dark{background:var(--ink)}
.cta-dark:hover{background:#2A2A28}
.cta-blue{background:var(--blue)}
.cta-blue:hover{background:#1530D6}

.browse{display:flex;align-items:center;gap:14px;padding:14px 20px;border-top:1px solid var(--rule);transition:background-color 160ms}
.browse:hover{background:#FAFAF9}
.fan{position:relative;width:84px;height:44px;flex-shrink:0}
.fan img{position:absolute;width:48px;height:34px;object-fit:cover;object-position:50% 0;border-radius:6px;box-shadow:0 0 0 1.5px #fff,0 2px 6px rgba(11,11,11,.12)}
.fan img:nth-child(1){left:0;top:6px;transform:rotate(-6deg);transform-origin:0 0}
.fan img:nth-child(2){left:18px;top:3px}
.fan img:nth-child(3){left:36px;top:6px;transform:rotate(6deg);transform-origin:0 0}
.browse-copy{flex:1;min-width:0;display:flex;flex-direction:column;gap:1px}
.browse-title{font-size:16px;line-height:20px;letter-spacing:-.01em}
.browse-sub{font-size:13px;line-height:18px;letter-spacing:.01em;color:var(--muted)}

.identity{display:flex;align-items:center;gap:10px;padding:${E}px ${E}px ${E}px 20px;border-top:1px solid var(--rule);flex-shrink:0}
.who{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
.wordmark{font-size:20px;line-height:22px;letter-spacing:-.02em}
.wordmark span{color:var(--blue)}
.hi{font-size:15px;line-height:20px;letter-spacing:.01em;color:var(--muted)}
.close{width:36px;height:36px;border-radius:999px;background:var(--surface);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.close:hover{background:var(--rule)}

@media (prefers-reduced-motion:reduce){
  .tab,.chev,.reveal,.sheet,:host([data-open]) .sheet{transition:none}
  .content,:host([data-open]) .content{transform:none;transition:opacity 150ms ease}
}
`;

    function be(e) {
        const t = d(e.name),
            s = e.paid ? `<s class="list-price" hidden></s><span class="price">${d(e.priceLabel)}</span>` : '<span class="pill">Free</span>',
            p = e.included.map(r => `<li><span class="inc-icon">${fe[r.kind]}</span><span class="inc-label">${d(r.label)}</span>` + (r.tags.length ? `<span class="inc-tags">${r.tags.map(c=>`<span class="inc-tag">${d(c)}</span>`).join("")}</span>` : "") + "</li>").join(""),
            n = f.showcase.filter(r => r.slug !== e.slug).slice(0, 3).map(r => `<img src="${d(r.src)}" alt="" loading="lazy" decoding="async">`).join(""),
            u = e.paid ? `Buy ${t} for ${d(e.priceLabel)}` : `Get ${t} free`;
        return `
<style>${me}</style>
<div class="dock">
  <button class="tab" type="button" aria-expanded="false" aria-controls="firdavs-callout-panel">
    <span class="row">
      <img class="face" src="${d(f.portrait.idle)}" alt="" width="28" height="28">
      <span class="names"><span class="t-name">${t}</span><span class="label"></span></span>
      <span class="chip" hidden></span>
      ${ge}
    </span>
    <span class="reveal" aria-hidden="true"><span><span class="proof-wrap"><span class="proof"></span></span></span></span>
  </button>
  <div class="sheet" part="panel">
    <div class="content" role="dialog" aria-label="${t} by firdavs" id="firdavs-callout-panel">
      <div class="scroll">
        <section class="product">
          <div class="product-head">
            <h2>${t}</h2>
            <span class="price-tag">${s}</span>
          </div>
          <p class="desc">${d(e.description)}</p>
          <ul class="included">${p}</ul>
          <div class="offer-regional" hidden>
            <img class="flag" alt="">
            <div><span class="offer-title"></span><span class="offer-sub">Regional price, applied at checkout</span></div>
          </div>
          <div class="offer-launch" hidden>
            <div class="offer-launch-head"><span class="offer-title"></span><span class="offer-left"></span></div>
            <div class="bar" aria-hidden="true"></div>
            <span class="offer-sub"></span>
          </div>
          <a data-track="cta" class="cta ${e.paid?"cta-dark":"cta-blue"}" href="${d(O(e.ctaUrl,e.slug))}" target="_blank" rel="noopener"><span class="cta-label">${u}</span>${G}</a>
        </section>
        <a data-track="see-all" class="browse" href="${d(O(f.catalogUrl,e.slug))}" target="_blank" rel="noopener">
          <span class="fan" aria-hidden="true">${n}</span>
          <span class="browse-copy"><span class="browse-title">See all templates</span><span class="browse-sub">SaaS, coaching, VC and more</span></span>
          ${G}
        </a>
      </div>
      <div class="identity">
        <div class="who">
          <a data-track="site" class="wordmark" href="${d(O(f.origin,e.slug))}" target="_blank" rel="noopener">firdavs<span>.</span>xyz</a>
          <p class="hi">Hi, I made this template.</p>
        </div>
        <button class="close" type="button" aria-label="Close">${he}</button>
      </div>
    </div>
  </div>
</div>`
    }

    function V(e, t) {
        return Array.from({
            length: e
        }, (s, p) => p >= e - t ? "<i data-left></i>" : "<i></i>").join("")
    }

    function xe(e, t) {
        return t.kind === "launch" ? `<span class="proof-head"><span>${t.limit-t.remaining} claimed</span><span>${t.remaining} of ${t.limit} left</span></span><span class="bar">${V(t.limit,t.remaining)}</span>` : t.kind === "regional" ? `<span class="proof-head"><span>Regional price for ${d(t.country)}</span><span>${t.discountPercent}% off</span></span><span class="proof-price"><img class="flag" src="${d(t.flag)}" alt=""><s>${d(t.basePrice)}</s><b>${d(t.price)}</b><span>applied at checkout</span></span>` : t.kind === "free" ? `<span class="proof-head"><span>Free Framer template</span><span>No card needed</span></span><span>${d(e.tagline||"")}</span>` : `<span>${e.included.map(s=>d(s.label)).join(" · ")}</span>`
    }

    function L(e) {
        return Number.isInteger(e) ? `$${e}` : `$${e.toFixed(2)}`
    }

    function ye(e) {
        try {
            return new Intl.DisplayNames(["en"], {
                type: "region"
            }).of(e)
        } catch {
            return e
        }
    }

    function Y(e) {
        return `${f.flagsUrl}${e.toLowerCase()}.svg`
    }

    function ke(e) {
        return te(e, {
            config: f.analytics,
            isOptedOut: () => !!z("localStorage").get("umami.disabled"),
            getPageContext: () => ({
                hostname: location.hostname,
                url: location.pathname,
                title: document.title,
                referrer: document.referrer,
                language: navigator.language,
                screen: `${screen.width}x${screen.height}`
            })
        })
    }
    async function we(e, t) {
        var n;
        const s = typeof AbortController == "function" ? new AbortController : null,
            p = s ? setTimeout(() => s.abort(), de) : 0;
        try {
            const u = await fetch(`${f.origin}/api/pricing/${encodeURIComponent(t.slug)}`, {
                credentials: "omit",
                signal: s == null ? void 0 : s.signal
            });
            if (!u.ok) return null;
            const r = await u.json();
            clearTimeout(p);
            const c = new URL(`${f.origin}/checkout/${encodeURIComponent(t.slug)}`);
            c.searchParams.set("src", "callout");
            const k = e.querySelector(".cta");
            k.href = c.href;
            const b = e.querySelector(".list-price"),
                S = e.querySelector(".price"),
                $ = e.querySelector(".cta-label"),
                x = () => {
                    b.textContent = L(r.basePrice), b.hidden = !1
                };
            if (((n = r.offer) == null ? void 0 : n.type) === "launch") {
                const {
                    limit: g,
                    remaining: a
                } = r.offer;
                x(), S.textContent = "Free";
                const l = e.querySelector(".offer-launch");
                return l.querySelector(".offer-title").textContent = `Free for the first ${g}`, l.querySelector(".offer-left").textContent = `${a} of ${g} left`, l.querySelector(".bar").innerHTML = V(g, a), l.querySelector(".offer-sub").textContent = `A launch thank-you. After that, it's ${L(r.basePrice)}.`, l.hidden = !1, k.classList.replace("cta-dark", "cta-blue"), $.textContent = `Claim ${t.name} free`, {
                    offer: "launch",
                    pricing: r,
                    tab: {
                        kind: "launch",
                        limit: g,
                        remaining: a
                    }
                }
            }
            if (r.discountPercent > 0 && r.price < r.basePrice && r.country) {
                const g = ye(r.country);
                x(), S.textContent = L(r.price);
                const a = e.querySelector(".offer-regional");
                return a.querySelector(".flag").src = Y(r.country), a.querySelector(".offer-title").textContent = `${r.discountPercent}% off for ${g}`, a.hidden = !1, $.textContent = `Buy ${t.name} for ${L(r.price)}`, {
                    offer: r.tier || "full",
                    pricing: r,
                    tab: {
                        kind: "regional",
                        price: L(r.price),
                        basePrice: L(r.basePrice),
                        discountPercent: r.discountPercent,
                        country: g,
                        flag: Y(r.country)
                    }
                }
            }
            return {
                offer: "full",
                pricing: r,
                tab: null
            }
        } catch {}
        return null
    }

    function Z(e) {
        var ee;
        if (document.querySelector("firdavs-callout")) return;
        ue();
        const t = document.createElement("firdavs-callout"),
            s = t.attachShadow({
                mode: "closed"
            });
        s.innerHTML = be(e), document.body.appendChild(t);
        const p = z("localStorage"),
            n = z("sessionStorage"),
            u = `firdavs-callout:opened:${e.slug}`,
            r = `firdavs-callout:teased:${e.slug}`,
            c = s.querySelector(".tab"),
            k = s.querySelector(".row"),
            b = s.querySelector(".label"),
            S = s.querySelector(".chip"),
            $ = s.querySelector(".proof"),
            x = s.querySelector(".close"),
            g = s.querySelector(".content");
        let a = !1,
            l = e.paid ? "full" : "free",
            w = [];
        const A = () => {
            const i = document.getElementById("__framer-badge-container"),
                o = (i == null ? void 0 : i.querySelector("a")) || (i == null ? void 0 : i.firstElementChild);
            return o ? o.getBoundingClientRect() : null
        };

        function F() {
            const i = t.hasAttribute("data-teaser");
            i && t.removeAttribute("data-teaser");
            const o = I => {
                    b.textContent = w[I].label, S.textContent = w[I].chip || "", S.hidden = !w[I].chip
                },
                m = I => (o(I), k.scrollWidth + 22),
                C = I => ie(w.length, {
                    viewport: window.innerWidth,
                    room: I,
                    widthOf: m
                });
            let y = C(window.innerWidth - B);
            const T = re({
                viewport: window.innerWidth,
                viewportHeight: window.innerHeight,
                tabWidth: m(y),
                flare: h,
                badge: A()
            });
            T.side === "left" ? (y = C(T.room), t.setAttribute("data-side", "left"), t.style.setProperty("--tab-room", `${T.room}px`)) : t.removeAttribute("data-side"), o(y), t.setAttribute("data-fit", String(y)), i && t.setAttribute("data-teaser", "")
        }

        function J(i) {
            w = ae(e.name, i), $.innerHTML = xe(e, i), F()
        }
        J(e.paid ? {
            kind: "full",
            price: e.priceLabel
        } : {
            kind: "free"
        }), (ee = document.fonts) == null || ee.ready.then(F), setTimeout(F, 1e3), setTimeout(F, 3e3);
        const v = ke(e);
        v.pageview();
        let P = 0;
        const K = i => {
                clearTimeout(P), t.hasAttribute("data-teaser") && (t.removeAttribute("data-teaser"), i && v.event("callout-teaser-folded", {
                    why: i
                }))
            },
            Q = i => {
                clearTimeout(P), P = setTimeout(() => K("timeout"), i)
            },
            X = () => {
                if (p.get(u) || n.get(r)) return;
                let i = !1;
                const o = () => {
                        i || (i = !0, window.removeEventListener("scroll", m), !a && (n.set(r, "1"), t.setAttribute("data-teaser", ""), v.event("callout-nudge-shown"), Q(oe)))
                    },
                    m = () => {
                        window.scrollY > window.innerHeight * .6 && o()
                    };
                window.addEventListener("scroll", m, {
                    passive: !0
                }), setTimeout(o, le)
            };
        c.addEventListener("pointerenter", () => {
            t.hasAttribute("data-teaser") && clearTimeout(P)
        }), c.addEventListener("pointerleave", () => {
            t.hasAttribute("data-teaser") && Q(ce)
        }), e.paid ? we(s, e).then(i => {
            i && (l = i.offer, v.setPricing(i.pricing)), v.seen((i == null ? void 0 : i.offer) || "full"), i != null && i.tab && J(i.tab), X(), a && D()
        }) : (v.seen("free"), X()), s.addEventListener("click", i => {
            var C, y;
            const o = (y = (C = i.target).closest) == null ? void 0 : y.call(C, "a[data-track]");
            if (!o) return;
            const m = o.dataset.track === "cta" ? l === "launch" ? "claim" : e.paid ? "buy" : "get-free" : o.dataset.track;
            v.click(m)
        });

        function D() {
            const i = Math.min(H, window.innerWidth - 16);
            t.style.setProperty("--panel-w", `${i}px`);
            const o = A(),
                m = (window.innerWidth - i) / 2,
                C = o && o.width > 0 && o.left < m + i && o.right > m && o.bottom > window.innerHeight - 120;
            t.style.setProperty("--badge-space", C ? `${Math.ceil(window.innerHeight-o.top+_)}px` : "0px"), g.style.height = "auto";
            const y = g.scrollHeight;
            g.style.height = "";
            const T = window.innerHeight - j - 16;
            t.style.setProperty("--panel-h", `${Math.min(y,T)}px`)
        }

        function M(i, o) {
            i !== a && (a = i, v.event(a ? "callout-open" : "callout-close", {
                via: o
            }), a ? (K(), D(), t.setAttribute("data-open", ""), p.set(u, "1"), requestAnimationFrame(() => x.focus({
                preventScroll: !0
            }))) : t.removeAttribute("data-open"), c.setAttribute("aria-expanded", String(a)), c.setAttribute("aria-label", a ? "Close" : `${b.textContent}, by firdavs`))
        }
        c.setAttribute("aria-label", `${b.textContent}, by firdavs`), c.addEventListener("click", () => M(!a, t.hasAttribute("data-teaser") ? "teaser" : "tab")), x.addEventListener("click", () => {
            M(!1, "button"), c.focus({
                preventScroll: !0
            })
        }), document.addEventListener("keydown", i => {
            i.key === "Escape" && a && (M(!1, "escape"), c.focus({
                preventScroll: !0
            }))
        }), document.addEventListener("pointerdown", i => {
            a && !i.composedPath().includes(t) && M(!1, "outside")
        }), window.addEventListener("resize", () => {
            F(), a && D()
        })
    }
    const R = pe();
    R && (document.body ? Z(R) : document.addEventListener("DOMContentLoaded", () => Z(R), {
        once: !0
    }))
})();